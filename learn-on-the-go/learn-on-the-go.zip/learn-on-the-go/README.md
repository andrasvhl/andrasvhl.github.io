# learn-on-the-go

Two Claude Code skills for getting reading material off the laptop: **send-to-kindle** emails
documents to your Kindle, **send-to-speechify** uploads them to your Speechify library so you can
listen on your phone. Say "send tomorrow's readings to my Kindle" or "put this article on
Speechify" and Claude finds the files, fetches readings that are only links, and delivers them.

Each skill is a short list of steps plus a vault note that holds your settings (address, account,
where your readings live) and the traps found in use. The skills never guess your Kindle address:
it lives in one note.

## Requirements

- Claude Code, run from (or with access to) your Obsidian vault.
- **Kindle:** Amazon's Send to Kindle by email, and one of two routes:
  - **script** (no extras): `code/send_to_kindle.py`, Python 3.9+, stdlib only, and an SMTP
    account (for Gmail, an app password).
  - **mcp:** a mail MCP server connected to Claude Code that can send attachments (for example a
    Google Workspace one).
- **Speechify:** a Speechify account, Chrome with the Claude in Chrome extension connected to
  Claude Code, and Speechify signed in there. Speechify has no import address, so the web upload is
  the only route that needs nothing on the phone.

## Install

```bash
# from the unzipped learn-on-the-go folder

# 1. the skills
mkdir -p ~/.claude/skills
cp -r skills/* ~/.claude/skills/

# 2. the settings notes, into your vault; then fill in the angle brackets
mkdir -p "$VAULT_PATH/_system"
cp templates/kindle.md templates/speechify.md "$VAULT_PATH/_system/"

# 3. only for the script route
mkdir -p ~/.local/share/learn-on-the-go
cp code/send_to_kindle.py ~/.local/share/learn-on-the-go/
cp config.example.env ~/.learn-on-the-go.env && chmod 600 ~/.learn-on-the-go.env
$EDITOR ~/.learn-on-the-go.env
python3 ~/.local/share/learn-on-the-go/send_to_kindle.py some.pdf --dry-run
```

On Amazon's side, add the sending account to your Approved Personal Document E-mail List
(Manage Your Content and Devices > Preferences > Personal Document Settings), or nothing arrives
and nothing tells you.

Skills in `~/.claude/skills/` work in every Claude Code session on the machine; copy them into
`<vault>/.claude/skills/` instead to scope them to the vault. Start a new session to load them.

## Usage

- "Send this PDF to my Kindle." / "Send tomorrow's readings for the strategy class to my Kindle."
- "Put these three articles on Speechify."
- Direct: `python3 send_to_kindle.py case.pdf notes.epub --subject "Week 3"`

For "tomorrow's readings" to work, describe in `_system/kindle.md` § Finding readings where your
material lives and how to tell which session is tomorrow. Both skills use that section.

## Notes

- Readings behind a login (a library proxy, a subscription) are opened in your own Chrome. When a
  sign-in page appears, Claude stops and gives you the link: passwords and 2FA stay with you.
- A reading that exists only as text in a note is rendered to PDF first.
- Amazon confirms nothing; it only emails when a document fails. Gmail caps a message at 25 MB, so
  the script splits large sets.
- Speechify: one file per upload, always from the library page's Add menu. The template's Gotchas
  section explains why.

## Layout

```
skills/      send-to-kindle, send-to-speechify
code/        send_to_kindle.py (the SMTP route)
templates/   kindle.md, speechify.md: your settings, for the vault's _system/ folder
config.example.env
```

## License

MIT, see `LICENSE`.
