---
type: reference
---

# Kindle delivery

Owns the address, the sending account and the traps for sending documents to the Kindle. The
`send-to-kindle` skill reads this note first and never looks the address up anywhere else (a mail
search for "kindle.com" can find an old or wrong address). Put this note at
`_system/kindle.md` in your vault and fill in the angle brackets.

## Config

| What | Value |
|---|---|
| Kindle address | `<your-kindle-address>` (Amazon > Manage Your Content and Devices > Preferences > Personal Document Settings) |
| Sending account | `<you@example.com>`, on Amazon's Approved Personal Document E-mail List |
| Route | `<mcp or script>`: `mcp` sends with your mail MCP server's send tool; `script` runs `send_to_kindle.py` |
| Script | `<~/.local/share/learn-on-the-go/send_to_kindle.py>` |
| Attachment staging dir (mcp route) | `<the folder your mail MCP server reads attachments from, if it has one>` |

## Conventions

- Subject and body are labels only. Subject: `<what it is>`; for a class:
  `<course> Session <N> <title>`. Body: one line.
- No confirmation step: the request to send is the authorization, and the recipient is your own
  device.

## Finding readings

<Where your reading material lives in the vault, e.g. "course folders under `Areas/School/`, one
folder per session, PDFs beside their notes". Say how to find tomorrow's session (a date line in a
prep note, a numbered folder).>

## Gotchas

- Mail caps a message at about 25 MB. Split large sets across messages (the script does this).
- No delivery confirmation comes back. Amazon only emails when a document fails.
- Only the approved sender works. A second account of yours will be silently dropped until you
  add it to the list.
