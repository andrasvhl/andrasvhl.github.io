---
type: reference
---

# Speechify delivery

Owns the route, the account and the traps for putting documents into the Speechify library, which
syncs to the phone app so they can be listened to on the go. The `send-to-speechify` skill reads
this note first. Put it at `_system/speechify.md` in your vault and fill in the angle brackets.

## Config

| What | Value |
|---|---|
| Account | `<you@example.com>`, signed in with `<Google / Apple / email>` |
| Plan | `<free or premium>` (the free plan caps the library at a few files) |
| Library | `https://app.speechify.com/library` |

## How it works

Speechify has no import address and no watched folder, so the route is the web app in your own
Chrome, driven by Claude in Chrome: open the library, click **Add**, find the file input, upload
**one** file, repeat per file. The library syncs to the phone on its own.

## Gotchas

- **One file per upload.** Passing several paths to the file input reports success, but only the
  first one lands.
- **Use the input that appears after clicking Add on the library page.** The home page's upload
  input can report success and deliver nothing after the first upload.
- **Clicking Add when the menu is already open closes it.** Take a screenshot to confirm the
  upload menu is showing before using the input.
- **Uploads can take a minute to appear.** Reload once more before re-uploading, or you get a
  duplicate.
- **Upload from a path inside the session's working folders** (the vault, or the session scratch
  folder). Paths outside them can be rejected by the upload tool.
- **Never pay to upgrade** on the user's behalf.
