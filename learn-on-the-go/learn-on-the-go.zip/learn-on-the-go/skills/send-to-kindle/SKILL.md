---
name: send-to-kindle
description: Send documents to the user's Kindle by email: readings, cases, PDFs, epubs, articles, any file. Use whenever they say "send to my Kindle", "put this on my Kindle", "send tomorrow's readings for <class> to my Kindle", or want something to read on the Kindle. The address and sending account are fixed in the vault note _system/kindle.md; never search mail for a Kindle address.
---

# send-to-kindle

**Read `_system/kindle.md` in the vault first.** It owns the address, the sending account, the
route and the traps. This file is only the steps. If the note is missing or still has angle
brackets in its Config table, stop and ask the user to fill it in (template in the
learn-on-the-go package).

## Steps

1. **Find the file(s).** A path the user gives, a file in the vault, or readings per the note's
   "Finding readings" section. Check every reading a session's prep material names, not only the
   files beside it.
   - A reading that is only a link: fetch it. If it sits behind a login (a library proxy, a
     paywall the user has access to), open it in the user's own browser with Claude in Chrome. If a
     sign-in page appears, stop and give the user the link; passwords and 2FA are theirs. Close
     the tab afterwards.
   - A reading that exists only as text in a note: render it to PDF in the session scratch folder
     (for example pandoc to HTML, then headless Chrome `--print-to-pdf`).
2. **Send**, by the route the note names:
   - **script:** `python3 <script> <files> --subject "<label>"`. It batches under the mail size
     cap. Run with `--dry-run` first when there are many files.
   - **mcp:** your mail MCP server's send tool, from the sending account to the Kindle address, no
     signature, one attachment per file. If the server only reads attachments from a staging
     folder, copy the files there, send, then delete the copies. Keep each message under 25 MB.
3. **Reply in two or three lines:** what was sent, for which session, and any reading that could
   not be fetched, with its link.

No confirmation step: the request is the authorization, and the recipient is the user's own
device.

## Improving this skill

When the user pushes back on how a run went, treat it as design input: turn it into concrete
options and let them choose. Record each adopted change here with its date and reason. Never edit
the skill while a run is in progress.
