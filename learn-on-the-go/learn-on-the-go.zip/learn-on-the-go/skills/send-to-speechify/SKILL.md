---
name: send-to-speechify
description: Upload documents to the user's Speechify library so they can listen to them on their phone: readings, cases, PDFs, articles. Use whenever they say "send to Speechify", "put this on Speechify", "I want to listen to tomorrow's readings", or want readings as audio for a commute or the evening. Uploads through the Speechify web app in the user's Chrome (Claude in Chrome); the library syncs to the phone.
---

# send-to-speechify

**Read `_system/speechify.md` in the vault first.** It owns the account, the plan limits and the
traps. This file is only the steps. Needs Claude in Chrome connected to the user's own Chrome, with
Speechify signed in.

## Steps

1. **Find the file(s):** a path the user gives, a file in the vault, or readings as in
   `_system/kindle.md` § Finding readings (same fetching rules for links and text-only readings).
2. **Check room.** Open `https://app.speechify.com/library`. If it asks for sign-in, stop and give
   the user the link. If the plan's file cap would be exceeded, say which files would not fit and
   ask what to drop.
3. **Upload one file at a time:** on the library page click **Add**, screenshot to confirm the
   upload menu is open, `find` the file input, upload a single path. Reload the library and repeat
   for each file.
4. **Verify** on the library page that every file is listed (allow a minute and one more reload
   before re-uploading anything), then close the tab.
5. **Reply in two or three lines:** what is in the library, for which session, and anything that
   could not be fetched, with its link.

No confirmation step: the request is the authorization, and the library is the user's own. Never
pay for an upgrade.

## Improving this skill

When the user pushes back on how a run went, treat it as design input: turn it into concrete
options and let them choose. Record each adopted change here with its date and reason. Never edit
the skill while a run is in progress.
