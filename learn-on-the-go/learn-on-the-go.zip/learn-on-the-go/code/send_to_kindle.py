#!/usr/bin/env python3
"""Email files to a Kindle through Amazon's Send to Kindle service. Stdlib only.

    python3 send_to_kindle.py case.pdf article.epub --subject "Week 3 readings"
    python3 send_to_kindle.py *.pdf --dry-run          # show the batches, send nothing

The route: an SMTP account that is on your Amazon "Approved Personal Document
E-mail List" sends the files as attachments to your Kindle address. Amazon
delivers to the device within minutes and only emails back when a document
fails. Files are batched so each message stays under the mail size cap
(Gmail: 25 MB including encoding overhead), one message per batch.

Settings come from the environment, falling back to an env file
(LOTG_ENV, default ~/.learn-on-the-go.env), KEY=value lines:

    KINDLE_ADDRESS   your Send to Kindle address (Amazon > Manage Your Content
                     and Devices > Preferences > Personal Document Settings)
    SMTP_USER        the sending account, which must be on the approved list
    SMTP_PASSWORD    for Gmail an app password, not the account password
    SMTP_HOST        default smtp.gmail.com
    SMTP_PORT        default 587 (STARTTLS)
"""
from __future__ import annotations

import argparse
import mimetypes
import os
import smtplib
import sys
from email.message import EmailMessage
from pathlib import Path

ENV_FILE = Path(os.environ.get("LOTG_ENV") or Path.home() / ".learn-on-the-go.env").expanduser()

# What Send to Kindle accepts by email (Amazon's list, Oct 2026).
ACCEPTED = {".pdf", ".doc", ".docx", ".txt", ".rtf", ".htm", ".html", ".png", ".gif",
            ".jpg", ".jpeg", ".bmp", ".epub"}
# Base64 grows a file by a third; keep the raw total well under 25 MB.
BATCH_BYTES = 17 * 1024 * 1024


def load_env() -> dict[str, str]:
    env: dict[str, str] = {}
    if ENV_FILE.exists():
        for line in ENV_FILE.read_text(encoding="utf-8").splitlines():
            line = line.strip()
            if line and not line.startswith("#") and "=" in line:
                k, v = line.split("=", 1)
                env[k.strip()] = v.strip()
    env.update({k: v for k, v in os.environ.items()
                if k in ("KINDLE_ADDRESS", "SMTP_USER", "SMTP_PASSWORD", "SMTP_HOST", "SMTP_PORT")})
    return env


def batches(files: list[Path], limit: int = BATCH_BYTES) -> list[list[Path]]:
    """Greedy, in the given order. A single file over the limit is its own batch (and will
    likely bounce; the caller is warned)."""
    out: list[list[Path]] = []
    cur: list[Path] = []
    size = 0
    for f in files:
        n = f.stat().st_size
        if cur and size + n > limit:
            out.append(cur)
            cur, size = [], 0
        cur.append(f)
        size += n
    if cur:
        out.append(cur)
    return out


def build(sender: str, to: str, subject: str, files: list[Path]) -> EmailMessage:
    msg = EmailMessage()
    msg["From"] = sender
    msg["To"] = to
    msg["Subject"] = subject
    msg.set_content(f"{len(files)} document(s): " + ", ".join(f.name for f in files))
    for f in files:
        ctype = mimetypes.guess_type(f.name)[0] or "application/octet-stream"
        main, _, sub = ctype.partition("/")
        msg.add_attachment(f.read_bytes(), maintype=main, subtype=sub, filename=f.name)
    return msg


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__.split("\n")[0])
    ap.add_argument("files", nargs="+", type=Path)
    ap.add_argument("--subject", default="", help="label only; default: the first file's name")
    ap.add_argument("--dry-run", action="store_true", help="print the batches, send nothing")
    a = ap.parse_args()

    files = [f.expanduser() for f in a.files]
    missing = [str(f) for f in files if not f.is_file()]
    if missing:
        print("not found: " + ", ".join(missing), file=sys.stderr)
        return 2
    odd = [f.name for f in files if f.suffix.lower() not in ACCEPTED]
    if odd:
        print("Send to Kindle does not accept: " + ", ".join(odd), file=sys.stderr)
        return 2

    groups = batches(files)
    subject = a.subject or files[0].stem
    for i, g in enumerate(groups, 1):
        mb = sum(f.stat().st_size for f in g) / 1e6
        warn = "  (over the size cap, may bounce)" if mb * 1e6 > BATCH_BYTES else ""
        print(f"message {i}/{len(groups)}: {mb:.1f} MB: " + ", ".join(f.name for f in g) + warn)
    if a.dry_run:
        return 0

    env = load_env()
    need = [k for k in ("KINDLE_ADDRESS", "SMTP_USER", "SMTP_PASSWORD") if not env.get(k)]
    if need:
        print(f"missing {', '.join(need)} (environment or {ENV_FILE})", file=sys.stderr)
        return 2
    host = env.get("SMTP_HOST", "smtp.gmail.com")
    port = int(env.get("SMTP_PORT", "587"))
    password = env["SMTP_PASSWORD"].replace(" ", "")   # app passwords are shown in groups of four
    with smtplib.SMTP(host, port, timeout=60) as smtp:
        smtp.starttls()
        smtp.login(env["SMTP_USER"], password)
        for i, g in enumerate(groups, 1):
            subj = subject if len(groups) == 1 else f"{subject} ({i}/{len(groups)})"
            smtp.send_message(build(env["SMTP_USER"], env["KINDLE_ADDRESS"], subj, g))
    print(f"sent {len(files)} file(s) in {len(groups)} message(s)")
    return 0


if __name__ == "__main__":
    sys.exit(main())
