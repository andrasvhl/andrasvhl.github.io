# telegram-bridge

Your Obsidian vault as a Telegram bot. You write (or speak) to the bot from your phone and a real
Claude Code session answers, running on a server with the vault as its working directory: the
vault's `CLAUDE.md`, your skills, MCP servers and a shell, exactly as in a terminal. Risky tool
calls (`rm -r`, `sudo`, `git push`, stopping services, sending mail) stop and show **Allow once /
Deny** buttons on your phone. Your laptop can be off.

It is a small Python daemon (about 4,000 lines, plus offline tests) on top of the Claude Agent SDK.

## What it does

- **Text, voice, photos, files.** Voice notes are transcribed (Groq Whisper, OpenAI as fallback)
  and the transcript is echoed back. Photos and files are saved into the vault under
  `Attachments/Telegram/<YYYY-MM>/` and handed to Claude as paths.
- **Sessions.** Each Telegram topic in your private chat with the bot is its own Claude session.
  Inside one topic, `/sessions` lists and switches between named sessions. `/new` starts fresh,
  `/stop` (or just "stop") interrupts, `/status` reports. Messages sent while Claude is working
  are folded into the next turn.
- **Approvals.** Sessions run with `bypassPermissions` plus an explicit ask list. Anything on the
  ask list waits for your tap; no tap within 2 minutes is a deny, and a deny is final for that
  call. Only your Telegram user id can tap.
- **Status line.** While a tool runs you see "Reading index.md..." or similar, deleted when the
  answer arrives.
- **Proactive messages.** Your own scripts can message you through the bot, with buttons:
  `runner.notify.send_telegram(text, buttons=[[("Label", "callback")]])`. Inside your quiet hours
  they arrive silently. Replying to one continues the conversation.
- **Safety rails.** The bot ignores everyone but you. Secrets the bridge holds (bot token,
  transcription keys, mail and push credentials) are removed from the environment Claude's shell
  sees. A stalled turn is killed by a watchdog. A transcript left broken by a crash means a fresh
  session and a one-line note, not a confused resume. Two copies can never poll one token (a lock
  file), and a second poller elsewhere raises an alert.

## Requirements

- A Linux server that is always on (a small VPS is plenty: two warm sessions use about 800 MB),
  with systemd and Python 3.11 or newer (developed on 3.14).
- Claude Code installed on the server and logged in (`claude` works in a shell there). The bridge
  uses that binary and its login; no API key is needed.
- Your vault on the server, kept in sync however you like (Obsidian Sync with a headless client,
  git, Syncthing). The bridge only needs a folder.
- A Telegram bot token from @BotFather, and your numeric Telegram user id.
- Optional: a Groq and/or OpenAI key for voice notes; Pushover and/or a Gmail app password for
  failure alerts.

## Install

The code expects to live at `~/automation` (the systemd unit and the allow rules assume it). If you
put it elsewhere, edit `units/tg-bridge.service` and set `TG_VT_RULES`.

```bash
# from the unzipped telegram-bridge folder
# 1. code and dependencies
cp -r code ~/automation
cp config.example.env ~/.automation.env
cd ~/automation
python3 -m venv .venv
.venv/bin/pip install -r requirements.txt

# 2. credentials: bot token and your user id at least
chmod 600 ~/.automation.env
$EDITOR ~/.automation.env

# 3. the reply style, inside your vault
mkdir -p ~/vault/_system/telegram-bridge
cp templates/reply-style.md ~/vault/_system/telegram-bridge/

# 4. tests (all offline; with the venv the SDK shape test runs too)
.venv/bin/python -m tests.tg_bridge

# 5. a first run by hand: send the bot "hi", then Ctrl-C
.venv/bin/python -m jobs.tg_bridge

# 6. the service
sed -i "s/<user>/$USER/g" units/tg-bridge.service
sudo cp units/tg-bridge.service /etc/systemd/system/
sudo systemd-analyze verify /etc/systemd/system/tg-bridge.service
sudo systemctl daemon-reload
sudo systemctl enable --now tg-bridge
journalctl -u tg-bridge -f
```

If your vault is not at `~/vault`, add `Environment=VAULT_PATH=/path/to/vault` to the unit's
`[Service]` section. The other path and timezone settings are listed at the bottom of
`config.example.env`.

**Check it from the phone:** "hi" gets an answer; `mkdir -p /tmp/asktest && rm -rf /tmp/asktest`
shows Allow/Deny; a voice note comes back as a transcript and an answer.

## Skills in bridge sessions

The bridge leaves Claude Code's `setting_sources` at the default, so every session loads the
vault's `CLAUDE.md` and your user-scope skills in `~/.claude/skills/` on the server. To use a
skill from your phone, install it there:

```bash
mkdir -p ~/.claude/skills
cp -r /path/to/some-skill ~/.claude/skills/        # a folder holding SKILL.md
```

Then ask for it by name or by what it does ("dump", "what are my to-dos"). The task-loop package
from the same page is a set of skills that works well this way.

## Configuration

Everything is in `config.example.env`, with comments. The ones you are most likely to touch:

| Setting | What it does |
|---|---|
| `TG_PERMISSION_MODE` | `bypassPermissions` (default) runs everything except the ask list; `default` asks for everything outside the allow list |
| `TG_ASK_EXTRA` | your own rules that should wait for a tap, `;`-separated, e.g. `Bash(my-send-script *)` |
| `TG_MODEL` | model alias for the sessions |
| `QUIET_HOURS_TZ`, `QUIET_HOURS_NOTE` | proactive messages arrive silently between "lights off" and your wake time, read from a Sleep row in a vault note (the task-loop package's working-conditions template has one); without it the defaults are 23:00 to 07:45 weekdays, 09:00 weekends |

The ask list lives in `jobs/tg_bridge/agent.py` (`ASK_RULES`). The mail rule names the send tool
of the Google Workspace MCP server registered as `gws`; if your mail MCP has another name, change
that line, or anything it sends will go without a tap.

## Optional: the maintenance brief buttons

`jobs/tg_bridge/proactive.py` handles one kind of proactive message out of the box: a weekly list of
things to fix, one message per item, each with **[Let Claude fix it] [Create task] / [Skip]**. A
job of yours writes the list as a note at `_system/maintenance/briefs/<YYYY-MM-DD>.md` containing
a fenced block tagged `maintenance-brief-items`:

````markdown
```maintenance-brief-items
{"brief": "2026-11-02", "items": [
 {"rank": 1, "title": "Backup timer is not enabled", "what": "...", "why": "...",
  "next_action": "Enable the timer", "effort": "10 min", "kind": "claude"}]}
```
````

and sends each item with `proactive.brief_buttons(date, rank)` as the buttons. "Create task"
writes a task note into `Inbox/` (`tools/todos.py`, the same format as task-loop). "Let Claude fix
it" also opens a topic and starts a session on the item, which ends with an `OUTCOME:` line; a fix
done without your input closes the task. If you do not write briefs, none of this ever runs.

## Known limitations

- **Your Telegram account is the key to the server.** Anyone who controls it controls a shell
  with your vault. Set a Telegram two-step verification password and an app passcode, and review
  Settings > Devices.
- **Claude can read every file the service user can,** including credential files. Only the
  bridge's own keys are scrubbed from its environment.
- **Ask rules are prefix matches on the command text.** `rm -fr`, `find -delete` or a script that
  deletes things will run without a tap. It is a backstop against the obvious form, not a sandbox.
- **Allow rules match the literal command.** `Bash(~/automation/bin/vt *)` and the absolute path
  form are different rules, which is why both are listed.
- **A blocked command gets no button, it just fails.** Keep deny rules for things you never want.
- **Never run a second copy against the same token.** Telegram answers both with HTTP 409. A
  short 409 right after a restart is the previous process's last poll and is normal.
- **Quiet hours deliver silently; they do not hold messages until morning.**
- **No audit log of every tool call.** That would need a `PreToolUse` hook.
- **One message has been seen to start more than one session** (Oct 30, 2026, under
  investigation). If it happens, `/status` shows it and `/stop` ends the extra turn.
- Claude Code's own scheduling tools (cron, wake-ups, Monitor) are denied in bridge sessions,
  because they die with the process. Schedule with systemd timers instead.

## Layout

```
code/
  jobs/tg_bridge/   the daemon: one file per concern, see its __init__.py
  runner/           paths and env file (config), logging (job), alerts (notify), quiet hours
  tools/todos.py    task-note writer used by the "Create task" button
  tests/tg_bridge/  offline tests: python -m tests.tg_bridge
  units/            the systemd unit
  bin/run-job       starts a job under the repo's .venv
  templates/        reply-style.md, for your vault
config.example.env
```

## License

MIT, see `LICENSE`.
