"""Shared paths and credentials for the bridge and any job you add beside it.

One credential file, one loader. Nothing reads the env file itself.

Every path can be overridden from the process environment (the systemd unit's
Environment= lines, or your shell):

    VAULT_PATH        your Obsidian vault             default ~/vault
    AUTOMATION_ENV    the credential file             default ~/.automation.env
    AUTOMATION_STATE  state dir (SQLite, locks, logs) default ~/.local/state/automation
    SMTP_HOST / SMTP_PORT  for the mail fallback      default smtp.gmail.com:587
"""

import os
from pathlib import Path

HOME = Path.home()


def _resolve_vault() -> Path:
    override = os.environ.get("VAULT_PATH")
    return Path(override).expanduser() if override else HOME / "vault"


VAULT = _resolve_vault()
INBOX = VAULT / "Inbox"

STATE_DIR = Path(os.environ.get("AUTOMATION_STATE") or HOME / ".local" / "state" / "automation")
LOCK_DIR = STATE_DIR / "locks"

ENV_FILE = Path(os.environ.get("AUTOMATION_ENV") or HOME / ".automation.env")

# Port 587 with STARTTLS. Some hosting providers block 25 and 465 outbound; a
# blocked port hangs until the timeout rather than refusing.
SMTP_HOST = os.environ.get("SMTP_HOST", "smtp.gmail.com")
SMTP_PORT = int(os.environ.get("SMTP_PORT", "587"))


def load_env() -> dict[str, str]:
    """Read the env file (KEY=value lines). Returns {} when absent, never raises."""
    if not ENV_FILE.exists():
        return {}

    env = {}
    for line in ENV_FILE.read_text(encoding="utf-8").splitlines():
        line = line.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        key, value = line.split("=", 1)
        env[key.strip()] = value.strip()
    return env


def ensure_dirs() -> None:
    STATE_DIR.mkdir(parents=True, exist_ok=True)
    LOCK_DIR.mkdir(parents=True, exist_ok=True)
