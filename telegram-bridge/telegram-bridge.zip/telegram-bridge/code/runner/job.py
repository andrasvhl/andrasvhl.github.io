"""Logging for the bridge. Straight to stdout, which systemd routes to journald."""


def log(message: str) -> None:
    """No log files of our own: journald rotates, a log file grows forever."""
    print(message, flush=True)
