# Canvas Archive

Keeps a complete, searchable copy of your Canvas courses in an Obsidian vault (or any folder of
markdown files), so you can still answer "what did that class say about X?" years after your
Canvas access is gone.

It talks to the Canvas REST API with your personal access token and writes one markdown note per
Canvas item, laid out like the course's Modules view:

```
Course Archive/
  Fall 2026/
    <Course title>/
      <Course title>.md          course anchor
      Modules.md                 every item, in Canvas order
      Syllabus.md
      3 - <Module name>/
        3 - <Module name>.md     the session's own page
        Pages/ Readings/ Materials/ Assignments/
      _Unfiled/                  announcements, discussions, items in no module
      _sync-log.md               what the last run did
  _files/<Course>/<Module>/      the binaries (PDFs, decks, spreadsheets)
```

Per course it pulls the syllabus, modules, every page, assignments with rubrics **and your own
submission, score and feedback**, announcements, discussion threads, quizzes where visible, and
every file. Then it extracts the text of each PDF, slide deck (speaker notes included), Word
file and spreadsheet into a note beside it, and, as a separate pass, fetches the readings the
course links out to, stripped down to the article itself. Readings behind a publisher login
become a worklist: save them from your browser into a drop folder under any name, and
`vt canvas adopt` works out which reading each file is from its contents.

Everything is incremental: a second run with nothing new on Canvas writes nothing and downloads
nothing.

It comes with a Claude Code skill, so you can say "archive my courses" or "what did week 3 of
my strategy class cover?" and Claude runs the tool or reads the archive for you.

**Built for Stanford's Canvas.** The pull works against any Canvas instance, but a few things
assume Stanford conventions: the default host is `canvas.stanford.edu`, course folders are
grouped into terms from Stanford-style course codes (`F26-ABC-123-01`), and some comments talk
about Stanford GSB course sites. On another school's Canvas, set `CANVAS_HOST` and check how
`tools/canvas/layout.py` derives the term before a full pull.

**Your archive is for you.** Cases, readings and slides are licensed to you as a student. Keep
the archive private; do not publish it.

## Requirements

- **Python 3.11 or newer.**
- **A Canvas personal access token.** In Canvas: Account > Settings > Approved Integrations >
  New Access Token. Schools often cap the lifetime (Stanford: 90 days), so note the expiry.
- For text extraction and readings: the Python packages in `code/requirements.txt` (pypdf,
  python-pptx, python-docx, openpyxl, trafilatura). The pull itself needs none of them.
- Optional, for scanned PDFs: `tesseract` and `pdftoppm` (poppler), e.g.
  `brew install tesseract poppler` or `sudo apt install tesseract-ocr poppler-utils`.
- Optional: `git` (folder moves keep history inside a repo), `rsync` (two-machine setups).
- Optional: Claude Code, for the skill.

## Install

```bash
unzip canvas-archive.zip -d ~              # creates ~/canvas-archive/
cd ~/canvas-archive/code
chmod +x bin/*
python3 -m venv .venv && .venv/bin/pip install -r requirements.txt
cp ../config.example.env ~/.automation.env && chmod 600 ~/.automation.env
$EDITOR ~/.automation.env                  # set VAULT_PATH (and CANVAS_HOST if not Stanford)
bin/set-canvas-token                       # paste the token (hidden) and its expiry
bin/vt canvas courses                      # lists your enrolments; writes nothing
```

If you unpack somewhere other than `~/canvas-archive`, change the path in `skill/SKILL.md`
§ Setup.

## Usage

```bash
cd ~/canvas-archive/code
bin/vt canvas courses                  # every enrolment, concluded included
bin/vt canvas plan                     # items and bytes per course, before downloading anything
bin/vt canvas pull --course 123456     # archive one course (the id is in the course URL)
bin/vt canvas pull                     # archive everything
bin/vt canvas extract                  # text from every PDF, deck and spreadsheet
bin/vt canvas links --plan             # which sites the readings live on; fetches nothing
bin/vt canvas links                    # fetch the readings
bin/vt canvas links --gated            # the readings that need your login
bin/vt canvas adopt --dry-run          # match PDFs you saved into _files/<Course>/_manual/
bin/vt canvas refresh                  # the current term, every step above in order
bin/vt canvas status                   # what is archived, what failed
```

Start with one course: `pull --course ID`, look at the result in Obsidian, then pull the rest.
Run `plan` first if the vault syncs anywhere with a storage quota: a full degree can be several
gigabytes of slides and PDFs. Most sync services can exclude a folder, so `_files/` can stay off
your phone while the extracted text syncs everywhere.

Put your own coursework in `<Course>/_mine/`; `vt canvas mine` extracts its text too, and the
tool never deletes anything there.

## Use it as a Claude Code skill

Claude Code loads skills from `~/.claude/skills/<name>/SKILL.md`:

```bash
mkdir -p ~/.claude/skills/canvas-archive
cp ~/canvas-archive/skill/SKILL.md ~/.claude/skills/canvas-archive/
```

Start a new session and ask, for example: "Archive my Canvas courses", "Refresh this term's
classes", "Which readings still need my login?", or a question about a class. The skill keeps
Claude on the tool (no scraping, no hand-written notes) and tells it how to read the archive.

## Optional: run it daily

`jobs/canvas_tasks.py` refreshes the courses you are enrolled in this term and keeps one task
note per assignment in `<vault>/Inbox/` (due dates follow Canvas, a submission marks the task
done). The task format is opinionated (frontmatter `type: action`, `status`, `due`, a
`projects:` link); read `tools/canvas/tasks.py` before enabling it, or use only the refresh.

```bash
bin/run-job canvas_tasks --dry-run      # plans and reports, writes nothing
mkdir -p ~/.config/systemd/user
cp units/canvas-archive@.service units/canvas-archive@canvas_tasks.timer ~/.config/systemd/user/
systemctl --user daemon-reload
systemctl --user enable --now canvas-archive@canvas_tasks.timer
```

The timer runs at 05:30 Pacific; edit `OnCalendar=` for your time zone. With cron instead:
`30 5 * * * $HOME/canvas-archive/code/bin/run-job canvas_tasks`.

## Test

```bash
cd ~/canvas-archive/code
python3 -m tests.canvas_stub_run       # whole pipeline against a fake Canvas, in a scratch folder
```

## Good to know

- **A 401 means the token expired.** Mint a new one and run `bin/set-canvas-token` again. The
  tool warns 14 days before the expiry you recorded.
- **`--prune` deletes** anything under a course that the run did not produce. Never rename a
  module folder by hand (use `vt canvas alias --load`), or the next pruned pull removes it.
- **Never hand-edit a generated note**; the next pull overwrites it. Your own notes can sit
  beside them as separate files.
- `unavailable:403` on a section is normal: many courses turn tabs off.
- `vt canvas order` writes Canvas's module order into the Obsidian
  flexplorer file-order plugin's settings, if you use it. Skip it
  otherwise.
- `vt move OLD NEW` moves a note or folder inside the vault and rewrites every link to it; the
  archive uses it when a course is renamed or changes enrolment status.

## Files

```
README.md               this file
LICENSE                 MIT
config.example.env      every setting, with placeholders
skill/SKILL.md          the Claude Code skill
code/bin/vt             entry point: vt canvas ..., vt move ...
code/bin/set-canvas-token   writes the token into your settings file safely
code/bin/run-job        runs a scheduled job
code/tools/canvas/      the archiver (API client, layout, rendering, extraction, readings)
code/tools/move.py      link-preserving moves inside the vault
code/jobs/              canvas_tasks.py (optional daily sync)
code/runner/            settings loader, push and mail, the small job runner
code/tests/             canvas_stub_run.py (offline, fake Canvas)
code/units/             systemd service and timer
code/requirements.txt   packages for extraction and readings
```
