"""The shared runner for scheduled jobs (a slim version of the original).

A job records checks and measurements. The runner handles the rest: a lock so
runs cannot overlap, a state file per job, memory carried between runs, and
the exit-code contract a scheduler (systemd, cron) keys off.

    from runner.job import Job

    with Job("flight_watch") as job:
        job.check("sources answer", ok=..., detail="...", tier=ROUTINE)

    exit 0  the job ran. It may have found problems; it reports them itself
            (CRITICAL by push, everything else in the log).
    exit 1  the job itself broke. Your scheduler's failure hook fires.

Pass --dry-run on the command line (or dry_run=True) to run the checks while
writing no memory and sending nothing.
"""

import argparse
import fcntl
import json
import os
import sys
import traceback
import urllib.error
import urllib.request
from dataclasses import asdict, dataclass
from datetime import datetime, timezone
from types import TracebackType

from . import config, notify

# Tiers: how loudly a failure may interrupt.
CRITICAL = "critical"     # pushes every run it fails
IMPORTANT = "important"   # logged when new
ROUTINE = "routine"       # logged when new, never pushes

# Owner: who resolves it.
YOU = "you"
AUTOMATIC = "automatic"
AUTOMATABLE = "automatable"


@dataclass
class Check:
    name: str
    ok: bool
    detail: str = ""
    tier: str = IMPORTANT
    owner: str = YOU
    key: str = ""
    ongoing: bool = False
    covers: str = ""


class AlreadyRunning(Exception):
    pass


class Job:
    def __init__(self, name: str, *, description: str = "", dry_run: bool | None = None,
                 watches: tuple[str, ...] = ()):
        self.name = name
        self.description = description or name
        self.watches = tuple(watches)
        self.checks: list[Check] = []
        self.records: dict[str, object] = {}
        self.started = datetime.now(timezone.utc)
        self._lock_handle = None
        self._skipped = False
        self._seen: set[str] = set()
        self.dry_run = ("--dry-run" in sys.argv) if dry_run is None else dry_run

        config.ensure_dirs()
        self.state_path = config.STATE_DIR / f"{name}.json"
        self.lock_path = config.LOCK_DIR / f"{name}.lock"
        self._memory_path = config.STATE_DIR / f"{name}.memory.json"

    # ---- the API a job uses ----------------------------------------------

    def check(self, name: str, ok: bool, detail: str = "", *,
              tier: str = IMPORTANT, owner: str = YOU, key: str = "",
              covers: str = "") -> bool:
        """Assert something. Returns ok, so it can gate further work.

        A non-critical check that also failed last run is marked ongoing and
        is not reported again, so an unresolved problem is not repeated forever.
        """
        ok = bool(ok)
        key = key or name
        ongoing = (not ok and key in self._seen and tier != CRITICAL)
        self.checks.append(Check(name=name, ok=ok, detail="" if ok else detail, tier=tier,
                                 owner=owner, key=key, ongoing=ongoing, covers=covers))
        return ok

    def record(self, name: str, value) -> None:
        """Note a measurement or what the job did. Never alerts."""
        self.records[name] = value if not isinstance(value, (list, dict)) or len(value) <= 3 \
            else f"{len(value)} items"

    def remember(self, data: dict) -> None:
        """Persist machine state for the next run. A dry run remembers nothing."""
        if self.dry_run:
            return
        merged = self.recall()
        merged.update(data)
        self._memory_path.write_text(json.dumps(merged, indent=2, default=str) + "\n",
                                     encoding="utf-8")

    def recall(self) -> dict:
        """What the previous run remembered. Empty dict on a first run."""
        try:
            return json.loads(self._memory_path.read_text())
        except (OSError, json.JSONDecodeError):
            return {}

    @property
    def failures(self) -> list[Check]:
        return [c for c in self.checks if not c.ok and not c.ongoing and c.tier != ROUTINE]

    @property
    def healthy(self) -> bool:
        return all(c.ok for c in self.checks)

    # ---- lifecycle -------------------------------------------------------

    def __enter__(self) -> "Job":
        try:
            self._acquire_lock()
        except AlreadyRunning:
            self._skipped = True
            self._write_state(status="skipped", note="previous run still in progress")
            log(f"{self.name}: skipped, previous run still holding the lock")
            raise SystemExit(0)
        self._seen = set(self.recall().get("failed_keys", []))
        self._ping("/start")
        log(f"{self.name}: started{' (dry run)' if self.dry_run else ''}")
        return self

    def __exit__(self, exc_type, exc: BaseException | None, tb: TracebackType | None) -> bool:
        if self._skipped:
            return False
        try:
            if exc is not None and not isinstance(exc, SystemExit):
                self._write_state(status="error", note=f"{type(exc).__name__}: {exc}")
                self._ping("/fail")
                log(f"{self.name}: ERROR {type(exc).__name__}: {exc}")
                log(traceback.format_exc())
                return False
            for slug in self.watches:
                if slug not in {c.covers for c in self.checks if c.covers}:
                    self.checks.append(Check(name=f"{slug}: checked, nothing to report",
                                             ok=True, tier=ROUTINE, covers=slug))
            self.remember({"failed_keys": sorted(c.key for c in self.checks if not c.ok)})
            self._write_state(status="ok" if self.healthy else "problem")
            self._ping("")
            self._report()
        finally:
            self._release_lock()
        return False

    def _report(self) -> None:
        for c in self.checks:
            if not c.ok and not c.ongoing:
                log(f"  - [{c.tier}] {c.name}: {c.detail}")
        crit = [c for c in self.failures if c.tier == CRITICAL]
        passed = len([c for c in self.checks if c.ok])
        log(f"{self.name}: {passed}/{len(self.checks)} checks passed")
        if not crit or self.dry_run:
            return
        subject = f"CRITICAL: {self.description}, {len(crit)} problem(s)"
        body = "\n".join(f"  !! {c.name}" + (f"\n        {c.detail}" if c.detail else "")
                         for c in crit)
        try:
            notify.push_or_mail(subject, body, priority=1, push_message=body[:1000])
        except Exception as exc:   # delivery failing must not fail the job
            log(f"{self.name}: alert delivery failed, {type(exc).__name__}: {exc}")

    # ---- plumbing --------------------------------------------------------

    def _acquire_lock(self) -> None:
        self._lock_handle = self.lock_path.open("w")
        try:
            fcntl.flock(self._lock_handle, fcntl.LOCK_EX | fcntl.LOCK_NB)
        except BlockingIOError:
            self._lock_handle.close()
            self._lock_handle = None
            raise AlreadyRunning(self.name)
        self._lock_handle.write(f"{os.getpid()}\n")
        self._lock_handle.flush()

    def _release_lock(self) -> None:
        if self._lock_handle is not None:
            fcntl.flock(self._lock_handle, fcntl.LOCK_UN)
            self._lock_handle.close()
            self._lock_handle = None

    def _write_state(self, *, status: str, note: str = "") -> None:
        """Written on every run: the job's own freshness signal."""
        finished = datetime.now(timezone.utc)
        state = {"job": self.name, "description": self.description, "status": status,
                 "started": self.started.isoformat(), "finished": finished.isoformat(),
                 "checks": [asdict(c) for c in self.checks],
                 "failures": [asdict(c) for c in self.failures],
                 "records": self.records, "note": note, "dry_run": self.dry_run}
        tmp = self.state_path.with_suffix(".json.tmp")
        tmp.write_text(json.dumps(state, indent=2, default=str) + "\n", encoding="utf-8")
        os.replace(tmp, self.state_path)

    def _ping(self, suffix: str) -> None:
        """Optional dead man's switch (healthchecks.io style). Never affects the job."""
        env = config.load_env()
        base = env.get(f"HEALTHCHECKS_URL_{self.name.upper()}") or env.get("HEALTHCHECKS_URL")
        if not base or self.dry_run:
            return
        try:
            urllib.request.urlopen(f"{base.rstrip('/')}{suffix}", timeout=10).close()
        except (urllib.error.URLError, OSError) as exc:
            log(f"{self.name}: heartbeat ping failed ({exc}), continuing")


def log(message: str) -> None:
    """Straight to stdout; systemd routes it to the journal, cron to its mail."""
    print(message, flush=True)


def parse_args(description: str) -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=description)
    parser.add_argument("--dry-run", action="store_true",
                        help="run the checks but push, log and mail nothing")
    return parser.parse_args()
