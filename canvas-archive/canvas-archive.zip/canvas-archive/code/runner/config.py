"""Shared paths and settings for every tool and job in this package.

One settings file, one loader. Settings come from the file named by
AUTOMATION_ENV (default ~/.automation.env), and a variable set in the process
environment wins over the file. A tool never reads the file itself.

    VAULT_PATH=/path/to/your/vault      the Obsidian vault (or any folder)

config.example.env lists every setting.
"""

import os
from pathlib import Path

HOME = Path.home()
ENV_FILE = Path(os.path.expanduser(os.environ.get("AUTOMATION_ENV", "~/.automation.env")))

_PREFIXES = ("VAULT_", "CANVAS_", "PUSHOVER_", "GMAIL_", "MAIL_", "SMTP_", "TRAVEL_",
             "FLIGHT_", "QUIET_", "AUTOMATION_", "HEALTHCHECKS_")


def load_env() -> dict[str, str]:
    """The settings file merged with the process environment. Never raises.

    A missing file is a normal state: tools that need no secrets keep working,
    and callers that need one say what is missing.
    """
    env: dict[str, str] = {}
    if ENV_FILE.exists():
        for line in ENV_FILE.read_text(encoding="utf-8").splitlines():
            line = line.strip()
            if not line or line.startswith("#") or "=" not in line:
                continue
            key, value = line.split("=", 1)
            env[key.strip()] = value.strip().strip('"').strip("'")
    for key, value in os.environ.items():
        if key in env or key.startswith(_PREFIXES):
            env[key] = value
    return env


def get(key: str, default: str = "") -> str:
    return load_env().get(key, "") or default


def _resolve_vault() -> Path:
    raw = get("VAULT_PATH")
    return Path(os.path.expanduser(raw)) if raw else HOME / "vault"


VAULT = _resolve_vault()
INBOX = VAULT / "Inbox"

STATE_DIR = Path(os.path.expanduser(get("AUTOMATION_STATE_DIR", "~/.local/state/automation")))
LOCK_DIR = STATE_DIR / "locks"

# Port 587 with STARTTLS. Some hosting providers block 25 and 465 outbound, and
# a blocked port hangs until timeout rather than refusing.
SMTP_HOST = get("SMTP_HOST", "smtp.gmail.com")
SMTP_PORT = int(get("SMTP_PORT", "587"))


def ensure_dirs() -> None:
    STATE_DIR.mkdir(parents=True, exist_ok=True)
    LOCK_DIR.mkdir(parents=True, exist_ok=True)
