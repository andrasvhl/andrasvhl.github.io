"""How a job reaches you: a push (Pushover) for what is timely, mail as the fallback.

Push breaks through Focus modes, so it is for things that lose value within
hours, such as a fare that may be gone tomorrow. Mail is only the record and
the fallback when a push fails. Both are optional: with neither configured,
jobs log what they would have sent.

Settings (config.example.env): PUSHOVER_USER, PUSHOVER_TOKEN for push;
GMAIL_USER, GMAIL_APP_PASSWORD and optionally MAIL_TO for mail.
"""

import json
import os
import smtplib
import sys
import urllib.error
import urllib.parse
import urllib.request
from email.message import EmailMessage

from . import config

# Anything a test process actually delivers says so. Tests stub these
# functions, but a missed stub reaches the real channel, and a test push that
# reads exactly like a real alert is worse than none.
TEST_LABEL = "[TEST] "


def in_test() -> bool:
    """True when the running program is one of the package's tests.

    `python3 -m tests.x` is recognised by the main module's name, `python3
    tests/x.py` by its path; AUTOMATION_TEST=1 forces it.
    """
    if os.environ.get("AUTOMATION_TEST") == "1":
        return True
    main = sys.modules.get("__main__")
    name = getattr(getattr(main, "__spec__", None), "name", "") or ""
    if name == "tests" or name.startswith("tests."):
        return True
    path = os.path.abspath(sys.argv[0]) if sys.argv and sys.argv[0] else ""
    return f"{os.sep}tests{os.sep}" in path


def _label(text: str) -> str:
    return text if not in_test() or text.startswith(TEST_LABEL) else TEST_LABEL + text


class MailUnavailable(Exception):
    """Raised when mail is not configured."""


def send_mail(subject: str, body: str) -> str:
    env = config.load_env()
    user = env.get("GMAIL_USER")
    # Google shows app passwords as four groups of four. Pasted with the
    # spaces they are 19 characters and Gmail rejects them.
    password = (env.get("GMAIL_APP_PASSWORD") or "").replace(" ", "")
    to = env.get("MAIL_TO", user)

    if not user or not password:
        raise MailUnavailable(f"{config.ENV_FILE} missing GMAIL_USER or GMAIL_APP_PASSWORD")

    msg = EmailMessage()
    msg["Subject"] = _label(subject)
    msg["From"] = user
    msg["To"] = to
    msg.set_content(body)

    with smtplib.SMTP(config.SMTP_HOST, config.SMTP_PORT, timeout=30) as smtp:
        smtp.starttls()
        smtp.login(user, password)
        smtp.send_message(msg)
    return to


class PushUnavailable(Exception):
    """Raised when push is not configured or Pushover refuses. Callers fall back to mail."""


PUSHOVER_URL = "https://api.pushover.net/1/messages.json"


def send_push(title: str, message: str, *, url: str | None = None,
              url_title: str | None = None, priority: int = 0,
              device: str | None = None, retry: int | None = None,
              expire: int | None = None) -> None:
    """Send a Pushover notification.

    priority: -1 quiet, 0 normal, 1 high (bypasses quiet hours). 2 (emergency,
    repeats until acknowledged) needs explicit retry and expire (seconds) from
    the caller; without them it is refused.
    """
    if priority not in (-1, 0, 1, 2):
        raise ValueError("priority must be -1, 0, 1 or 2")
    if priority == 2 and not (retry and expire and 30 <= retry and expire <= 3600):
        raise ValueError("priority 2 needs retry >= 30 and expire <= 3600 seconds")
    env = config.load_env()
    user, token = env.get("PUSHOVER_USER"), env.get("PUSHOVER_TOKEN")
    if not user or not token:
        raise PushUnavailable(f"{config.ENV_FILE} missing PUSHOVER_USER or PUSHOVER_TOKEN")

    fields = {"token": token, "user": user, "title": _label(title)[:250],
              "message": message[:1024], "priority": str(priority)}
    if device:
        fields["device"] = device[:25]
    if priority == 2:
        fields["retry"], fields["expire"] = str(retry), str(expire)
    if url:
        fields["url"] = url[:512]
        if url_title:
            fields["url_title"] = url_title[:100]
    req = urllib.request.Request(PUSHOVER_URL, data=urllib.parse.urlencode(fields).encode())
    try:
        with urllib.request.urlopen(req, timeout=20) as resp:
            reply = json.loads(resp.read().decode("utf-8", errors="replace") or "{}")
    except urllib.error.HTTPError as exc:
        detail = exc.read().decode("utf-8", errors="replace")[:300]
        raise PushUnavailable(f"Pushover HTTP {exc.code}: {detail}")
    except (urllib.error.URLError, OSError) as exc:
        raise PushUnavailable(f"Pushover unreachable: {type(exc).__name__}: {exc}")
    # Pushover signals success with status 1; anything else is a refusal,
    # never a silent success.
    if reply.get("status") != 1:
        raise PushUnavailable(f"Pushover refused: {reply.get('errors') or reply}")


def push_or_mail(subject: str, body: str, *, push_message: str, priority: int = 0,
                 url: str | None = None, url_title: str | None = None) -> str:
    """Push; mail only when the push fails. Returns "push" or the mail recipient.

    The fallback mail says [PUSH FAILED] in its subject, because that mail is
    then the only alert. Raises MailUnavailable when both channels are down.
    """
    try:
        send_push(subject, push_message, priority=priority, url=url, url_title=url_title)
        return "push"
    except PushUnavailable as exc:
        return send_mail(f"[PUSH FAILED] {subject}",
                         f"The push for this alert failed ({exc}), so this mail is the only "
                         f"alert.\n\n{body}")
