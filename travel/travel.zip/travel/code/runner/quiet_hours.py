"""When a proactive push should wait: a nightly window from your settings.

    QUIET_HOURS=23:00-07:45      lights off to wake, every day
    QUIET_TZ=America/Los_Angeles any IANA time zone

With QUIET_HOURS unset or empty, nothing is ever held back. A value that does
not parse falls back to 23:00-07:45 and says so in the log line of the caller.
"""

import re
from dataclasses import dataclass
from datetime import datetime, time, timedelta
from zoneinfo import ZoneInfo

from . import config

DEFAULT = "23:00-07:45"


@dataclass(frozen=True)
class Window:
    start: time | None
    end: time | None
    source: str


def window() -> Window:
    raw = config.get("QUIET_HOURS", "").strip()
    if not raw:
        return Window(None, None, "off")
    m = re.fullmatch(r"(\d{1,2}):(\d{2})\s*-\s*(\d{1,2}):(\d{2})", raw)
    if not m:
        m = re.fullmatch(r"(\d{1,2}):(\d{2})\s*-\s*(\d{1,2}):(\d{2})", DEFAULT)
        src = f"defaults: QUIET_HOURS={raw!r} did not parse"
    else:
        src = "settings"
    a, b, c, d = (int(x) for x in m.groups())
    return Window(time(a, b), time(c, d), src)


def tz() -> ZoneInfo:
    return ZoneInfo(config.get("QUIET_TZ", "UTC"))


def is_quiet(now: datetime | None = None, win: Window | None = None) -> bool:
    win = win or window()
    if win.start is None:
        return False
    t = (now or datetime.now(tz())).astimezone(tz()).time()
    if win.start <= win.end:
        return win.start <= t < win.end
    return t >= win.start or t < win.end


def next_loud(now: datetime | None = None, win: Window | None = None) -> datetime:
    win = win or window()
    now = (now or datetime.now(tz())).astimezone(tz())
    if win.end is None:
        return now
    day = now.date() if now.time() < win.end else now.date() + timedelta(days=1)
    return datetime.combine(day, win.end, tz())
