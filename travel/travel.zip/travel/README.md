# Travel

Door-to-door trip planning with Claude Code, plus a flight price watch that runs on its own.

Most flight search compares one airport with another on one site. This package helps Claude do
what a patient friend would: look at every airport within a few hours of where you actually
start and where you actually need to be, price the train or drive to each, check a few days
around your arrival, try the usual tricks (hidden-city, self-transfer, open-jaw, stopovers,
award seats), include your bags in every price, and tell you whether to buy now or wait. If you
decide to wait, a small job re-prices the trip twice a day and sends you a push when a fare
looks like a deal.

It has two halves:

- **The skill** (`skill/`): instructions that teach Claude Code the method. This is where the
  judgement lives: what to ask you, what to search, how to compare, what to verify.
- **The code** (`code/`): three command-line search helpers the skill calls, and the watch job.
  - `vt flights`: Skiplagged and Kiwi.com fares over a whole grid of airports and days in one
    call, flagging hidden-city fares, self-transfers and missing bags.
  - `vt trains`: European rail and bus connections door to door, from Transitous.
  - `vt ferries`: ferry sailings and fares from Ferryhopper.
  - `jobs/flight_watch.py`: the price watch.

Claude never pays, signs in or sends anything for you. It hands you booking links, and on
request fills a booking form up to the payment page; passport numbers, card details and the pay
click stay yours.

## Requirements

- **Python 3.11 or newer.** Standard library only, nothing to `pip install`.
- **Claude Code**, for the skill. The command-line tools also work on their own.
- **No API keys for the searches.** Skiplagged, Kiwi.com and Ferryhopper publish free public
  endpoints, and Transitous is an open community service. Be polite: one flight grid at a time,
  a few train queries a minute.
- Optional, for deal alerts: a [Pushover](https://pushover.net) account (push to your phone),
  or a Gmail address with an app password (mail fallback).
- Optional, for the unattended watch: a machine that stays on (a small Linux server, or any
  always-on computer) with systemd or cron.
- Optional, for the confirmation steps: a browser extension that lets Claude read web pages
  (Kayak, Google Flights, airline sites). Without it the skill still finds candidates, but it
  will tell you the prices are unconfirmed.

## Install

```bash
unzip travel.zip -d ~                 # creates ~/travel/
cd ~/travel
cp config.example.env ~/.automation.env && chmod 600 ~/.automation.env
$EDITOR ~/.automation.env             # set VAULT_PATH, and Pushover if you want alerts
chmod +x code/bin/*
code/bin/vt flights search SFO HEL 2027-06-11     # a first search, about 30 seconds
```

If you unpack somewhere other than `~/travel`, change the paths in `skill/SKILL.md` § Setup.

Then make a notes folder for trips and copy the profile template into it:

```bash
mkdir -p ~/vault/Travel
cp "skill/profile/Travel Profile.md" ~/vault/Travel/
```

Fill in `Travel Profile.md` (your bases, who can drive you, bags, loyalty programs, how much
risk you accept) and `skill/reference/airports.md` (the airports near your bases). The skill
works without them, but asks more questions.

## Use it as a Claude Code skill

Claude Code loads skills from `~/.claude/skills/<name>/SKILL.md`. Copy the whole `skill/`
folder there, so its `reference/` files come along:

```bash
mkdir -p ~/.claude/skills
cp -r ~/travel/skill ~/.claude/skills/travel
```

Optionally register the three free MCP servers, so Claude can also call them directly:

```bash
claude mcp add --scope user --transport http skiplagged https://mcp.skiplagged.com/mcp
claude mcp add --scope user --transport http kiwi https://mcp.kiwi.com
claude mcp add --scope user --transport http ferryhopper https://mcp.ferryhopper.com/mcp
```

Start a new Claude Code session and ask in plain words, for example:

- "Cheapest way from Oakland to Stockholm around June 12, one checked bag."
- "I need to be in Helsinki by 6 pm on June 12. Is $640 from SFO a good price?"
- "Watch this trip and tell me when it drops."

Or type `/travel`. Claude asks a few questions in one message (exact start and end places,
lifts, bags, passengers), searches, confirms prices on deal pages, and writes a trip page to
`<vault>/Travel/`.

## Use the tools on their own

```bash
cd ~/travel/code
bin/vt flights search SFO,OAK HEL,ARN 2027-06-10..2027-06-12 --bag
bin/vt flights search SFO HEL 2027-06-11 --return 2027-06-25 --adults 2
bin/vt flights calendar SFO HEL 2027-06-11          # cheapest fare per day, about +-30 days
bin/vt trains stations "Lyon"
bin/vt trains journeys "Paris Gare de Lyon" "Lyon Part-Dieu" --date 2027-06-12 --time 08:00
bin/vt ferries search Split Hvar 2027-06-12 --tz Europe/Zagreb
```

Prices from `vt flights` are leads, not quotes: always confirm on the seller's page before
booking. All prices are in USD (converted at the ECB daily rate).

## The price watch

A watch is a fenced block of JSON inside any trip page under `TRAVEL_TRIPS_DIR`:

````
```flight-watch
{"id": "hel-jun", "from": ["SFO", "OAK"], "to": ["HEL"],
 "dates": "2027-06-10..2027-06-12", "stops": 1, "bag": true,
 "target_usd": 650, "until": "2027-04-15"}
```
````

- `id`: a short name; the price history is keyed on it.
- `from`, `to`: every airport worth considering at each end.
- `dates`: a day, a comma list, or `A..B`. `return` (optional) makes it a round trip.
- `bag: true` ignores hidden-city fares. `adults` (default 1) makes prices totals.
- `target_usd` (optional): push at or under this price. `until` (optional): stop afterwards.

The job pushes only deals: at or under target, at least 12 % and $40 under the usual price once
it has four checks, or a new low by 5 %. It pushes each deal once, and again only after a
further 5 % drop or a week. Everything it sees goes to the status page, which the skill reads
for the trend. It never edits your trip pages.

Try it without sending anything:

```bash
cd ~/travel/code
bin/run-job flight_watch --dry-run
python3 -m tests.flight_watch        # offline test, no network
```

Run it twice a day with systemd (Linux, as a user unit):

```bash
mkdir -p ~/.config/systemd/user
cp ~/travel/code/units/travel@.service ~/travel/code/units/travel@flight_watch.timer ~/.config/systemd/user/
systemctl --user daemon-reload
systemctl --user enable --now travel@flight_watch.timer
loginctl enable-linger "$USER"       # keep it running when you are logged out
```

The timer fires at 08:10 and 18:10 Pacific; edit `OnCalendar=` for your time zone. With cron
instead: `10 8,18 * * * $HOME/travel/code/bin/run-job flight_watch`.

The watch only sees Skiplagged and Kiwi. If your trip pages live in an Obsidian vault on
another computer, sync the vault to the machine running the job (Obsidian Sync, Syncthing, git).

## Limits

- No Southwest anywhere in the automated path; Google Flights covers it in the interactive run.
- `vt trains` has no fares, and timetables end at the next published timetable change.
- Kiwi cannot tell a protected interline itinerary from a self-transfer, so mixed carriers are
  flagged self-transfer.
- No hotels, by design.
- The skill's rules about airlines, fares and loyalty programs were checked in autumn 2026.
  They change; correct `skill/reference/playbook.md` when you find one that has.

## Files

```
README.md               this file
LICENSE                 MIT
config.example.env      every setting, with placeholders
skill/SKILL.md          the method, for Claude Code
skill/reference/        playbook (hacks, loyalty, timing), sources, airports template
skill/profile/          blank Travel Profile to fill in
code/bin/vt             command-line entry point
code/bin/run-job        runs a job: bin/run-job flight_watch
code/tools/             flights.py, trains.py, ferries.py
code/jobs/              flight_watch.py
code/runner/            settings loader, push and mail, the small job runner, quiet hours
code/tests/             flight_watch.py (offline)
code/units/             systemd service and timer
```
