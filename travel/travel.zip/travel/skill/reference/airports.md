# Airports and ground legs from your bases

Read by the `travel` skill to build the candidate set (SKILL.md Step 2). **Fill this in for
your own bases**: one section per place trips usually start from, one row per airport you would
consider. Drive times can come from Google Maps or an OSRM estimate without traffic; note the
date you measured, add a margin at peak times, and check live when a margin decides the answer.
Who can drive you is in the Travel Profile § 2.

**Never assume a trip starts at a base.** The skill asks where each leg starts and ends; these
tables only supply the ground leg once the place is confirmed.

For a destination that is not one of your bases, the skill builds the same table on the fly:
every airport within about 4 to 5 hours by train, bus or pickup.

---

## <Base 1: town, country> (<what it is: home, family, work>)

<Who can drive you from here, and how far. Which airport you prefer, if any.>

| Airport | Drive | km | Main airlines | Without a car |
|---|---|---|---|---|
| <IATA> <name> | <h> | <km> | <airlines> | <train or bus, and how long> |
| <IATA> <name> | <h> | <km> | <airlines> | <train or bus, and how long> |

Just over your drive limit, so ask before counting on a drive: <IATA list>.

## <Base 2: town, country>

| Airport | Drive | km | Transit |
|---|---|---|---|
| <IATA> <name> | <h> | <km> | <how, and how long> |

<Notes: which airport has the long-haul flights, which one has cheaper domestic fares or
airlines no search tool covers.>

---

## Example (delete once you have your own)

## Helsinki, Finland (example base)

| Airport | Drive | km | Main airlines | Without a car |
|---|---|---|---|---|
| HEL Helsinki | 0.4 h | 19 | Finnair hub, most European airlines, long-haul to Asia and the US | Train from the central station, about 30 min |
| TMP Tampere | 2.0 h | 175 | few (seasonal and budget) | Train to Tampere about 1 h 45, then bus |
| TKU Turku | 2.0 h | 165 | few | Train to Turku about 2 h, then bus |
| ARN Stockholm | flight or overnight ferry | | SAS hub, many long-haul | Overnight ferry Helsinki → Stockholm, about 17 h |
