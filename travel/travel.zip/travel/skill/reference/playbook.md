# Travel playbook: hacks, loyalty programs, buy timing

Read by the `travel` skill on every run. Airline rules change: confirm a rule on the airline's
own page before a recommendation depends on it, and when one has changed, fix it here.

---

## Hacks

Go through every item on every trip. For each one, write in the trip page whether it applied
and what it saved. "Not applicable" is a fine answer; "not checked" is not.

### 1. More airports at both ends
The core of the skill (SKILL.md Step 2). Price the ground leg for each airport (airports.md); a
$60 fare saving 3 hours away is not a saving if the train costs $70.

### 2. Arrive early
Search arrivals on the day and up to 2 days before it. The day before is often far cheaper on
peak dates.

### 3. Positioning flight
A cheap short-haul on its own ticket to a hub where the long-haul is much cheaper (in Europe:
AMS, CDG, FRA, MAD, HEL, LHR, IST and similar). It is a separate ticket, so allow at least 3
hours, or a night, before the long-haul, and assume the bag has to be re-checked.

### 4. Hidden-city (skiplagging)
Buy A → C via B and leave at B, because A → C is cheaper than A → B. `vt flights` flags these
fares `HIDDEN-CITY`. Rules:
- **Carry-on only.** A checked bag goes on to C.
- **One-way only.** Missing a leg cancels the rest of the ticket, return included.
- **No frequent-flyer number on the booking.** Airlines can take away miles and status.
- If the flight is cancelled, you are rebooked to C, not to B.
- You need a passport and any visa that C requires, and on an international ticket you may be
  asked at check-in for proof of onward travel.
- Some airlines enforce against it actively. In the EU it is a contract matter, not a crime.
- Use it only when the saving is really big: by default 30 % and $150 under the best regular
  fare (or the threshold in the Travel Profile).

### 5. Self-transfer and virtual interlining
Separate tickets on different airlines, which Kiwi builds and `vt flights` flags as
`self-transfer`. Make it safe:
- Allow at least 2.5 hours inside Schengen and at least 4 hours when there is a border or a bag
  to re-check.
- Avoid the last flight of the day as the second leg.
- Kiwi's Guarantee covers a missed connection only on bookings made through Kiwi.
- A transit visa may be needed for landside transfers (US, UK, China and others).
- **Always also price the halves separately** from the best sellers, a bag fee on each leg,
  against the bundle. Name the backup flight if the first leg is late.
- Present it as **2 tickets** and name who bundles it, never as one ticket.

### 6. Round trip, two one-ways, or mixed airlines
Price all three for every return trip. Round trips often win on long-haul legacy carriers;
one-ways and mixed airlines often win short-haul and with budget airlines, and each leg can then
be changed separately.

### 7. Throwaway return
When a round trip is cheaper than the one-way you need, buy the round trip and skip the return.
Skipping the *last* segment is the low-risk form. Same frequent-flyer rule as hidden-city.

### 8. Open-jaw and multi-city
Fly into one city and out of another instead of going back to the start point. Price it as one
multi-city ticket and also as separate one-ways.

### 9. Free stopovers on cash tickets
- **TAP:** free stopover in Portugal, up to 10 days. Book on flytap.com, not an agent.
- **Icelandair:** free stopover in Reykjavík, 1 to 7 days. Cheaper fares may cap the length.
- **Turkish:** a free Istanbul hotel night or two on qualifying tickets. Conditions vary.
- **Qatar:** discounted Doha stopover hotels through Discover Qatar.
- **Finnair:** no formal programme, but Helsinki stops are easy as multi-city.
Offer a stopover when a route goes through one of these hubs anyway.

### 10. Market and currency
The same flight can cost less in another country's market. On Google Flights, set `&gl=` to the
departure country and then the destination country. On airline sites, switch the country
selector. Before recommending a foreign-currency fare, check the card's foreign-exchange fee.

### 11. Student and youth fares
If the Travel Profile says the user is a student (or young enough for youth fares):
- **Lufthansa Group** (LH, LX, OS, SN): student fares, verified through a free Travel ID account
  on lufthansa.com (desktop site), usually with 2 × 23 kg bags and easier changes. Not always
  the cheapest, not offered inside Europe.
- **Air France / KLM** youth and student fares: age-limited, economy only, bags and changes
  included. Check the departure-country restrictions on the booking page.
- Student travel agencies (age limits apply).
Check them when the trip is long-haul and a bag is needed; the free bags alone can win.

### 12. Budget-airline airports
Secondary airports (Charleroi, Beauvais, Hahn, Eindhoven, Weeze and the like) are served by
Ryanair, Wizz and Transavia, which metasearch prices badly. Check the airline's own site and add
the bag and seat fees. airports.md has the drive time to each one.

### 13. Train instead of a plane, and train to the plane
- Under about 5 hours by train, compare against flying door to door. City-centre stations
  usually win.
- Railcards from the profile (BahnCard, Railcard, Carte Avantage and so on) change the fare.
- Air-rail tickets (Lufthansa Express Rail, Rail&Fly and others) put the train to the airport on
  the flight ticket, so a late train is covered.

### 14. Bags
A basic fare plus a paid bag can beat the standard fare, or lose to it. Price what will actually
be carried. Budget-airline bag fees are often higher at the airport than online. A Kiwi fare
marked `no bag` needs the airline's bag fee added.

### 15. Flexible destination
If the destination is open, use Skiplagged's "anywhere" search or Google Flights Explore.

### 16. Day of the week
Midweek departures often run cheaper than weekend ones. The day of booking hardly matters.

### 17. Pair legs across trips (back-to-back and nested round trips)
A round trip is often far cheaper than one one-way, so build round trips out of legs from
**different trips**. Example: you need Helsinki → New York now, and have a wedding in Helsinki
three months later. Book Helsinki → New York now as the outbound of a round trip whose return
brings you back for the wedding, instead of two one-ways.
- **Inputs:** the pairing scan (SKILL.md, Read first, item 6). Only confirmed trips.
- **Shapes:** this trip's leg + the opposite-direction leg of a later trip on one ticket; two
  overlapping round trips (nested); open-jaws when the later trip starts or ends elsewhere.
- **Rules that break it:**
  - Legs must be flown **in order**. Missing the outbound cancels the return.
  - Most tickets are valid **12 months** from the first flight, and some fares have a shorter
    maximum stay: read the fare rules.
  - The ticket is priced in the country of the **first** departure, so price both directions.
  - If the later trip's date is not fixed, choose a fare with cheap date changes, and say what a
    change costs.
  - Never pair so that the uncertain trip is the *first* leg.
- **Present it** in the combinations table with both tickets' legs, which trip each belongs to,
  and that trip's certainty.

---

## After booking

- **US 24-hour rule:** for flights to or from the US booked at least 7 days before departure,
  the airline must allow free cancellation within 24 hours, or a free 24-hour hold. Use it to
  lock a fare and keep looking.
- **Price drops:** US airlines give a credit for the difference on non-basic fares. Many
  European and budget airlines do not.
- **EU261:** €250, €400 or €600 by distance for an arrival delayed 3 hours or more, a
  cancellation with under 14 days' notice, or denied boarding. It covers flights departing the
  EU on any airline, and flights into the EU on EU airlines.
- **Schedule changes:** a significant change usually opens a free rebooking or a refund.

---

## Loyalty programs

The user's programs, balances and status are in the Travel Profile. General rules:

- **Alliances:** an award on a partner airline usually books through your program's own site.
  Star Alliance, oneworld and SkyTeam partners also earn on cash tickets, segment by segment.
- **Surcharges are the catch.** Some programs add fuel surcharges of several hundred dollars to
  long-haul awards, so always compare the **total cash co-pay**, not the miles alone.
- **Value test:** (cash fare − award cash co-pay) ÷ miles. Compare with the program's usual
  value (published valuations, often 1 to 1.5 US cents a mile). Under that, pay cash and keep
  the miles.
- **Finding seats without signing in:** alliance airlines release the same "saver" seats to
  every partner program, so a saver seat that united.com (Star Alliance), aa.com or
  alaskaair.com (oneworld) shows without sign-in is usually bookable through a partner program
  too. The price is not your program's: read that on its own site. Some airlines show their own
  members extra seats that partners never see.
- **Award search tools:** Seats.aero (free tier, cached), Roame (free tier up to 60 days),
  PointsYeah. A paid tier is worth it mainly with transferable points across many programs.
- **Never put a frequent-flyer number on a hidden-city or throwaway booking.**

### Earning miles on cash tickets

Every option shows the miles it earns. How to work it out:
- **Revenue-based programs** (many airlines' own tickets): miles per currency unit of the base
  fare plus carrier surcharges, without government taxes, seats or extra bags. Take the
  fare/tax split from the booking page; if only the total is visible, estimate and mark it.
- **Partner flights:** distance × the booking-class percentage. Look it up at
  `https://www.wheretocredit.com/en/<airline code>/<booking class>` (pick your program's row).
  The cheapest classes often earn 0 to 25 %, some earn nothing: write "0 (class X does not
  earn)" rather than leaving it out.
- **Check every segment's airline against the partner list, never assume.** A mixed itinerary
  earns only on the segments that credit. Budget airlines earn nothing in most programs.
- **Value:** count earned miles at the same cents-per-mile figure used for redeeming.

---

## Buy timing

The verdict is Buy now, Book by <date>, or Wait and watch. **Evidence, strongest first:**

1. **This trip's own watch history** (the status page): its low, median and trend.
2. **Google Flights price insight:** "low / typical / high" for this route and date, the typical
   price range, and the price-history graph.
3. **`vt flights calendar ORIG DEST DAY`:** today's cheapest fare for each day about 30 days
   around the date, which shows whether the chosen day is a peak.
4. **Typical booking windows** (re-check these yearly):
   - US domestic: cheapest about 1 to 3 months out.
   - International: 2 to 8 months out; US to Europe has tended to be cheapest 2 to 3 months out.
   - Holidays: book earlier; Christmas lows have been about 8 weeks out.
   - Fares tend to step up as the advance-purchase thresholds close at 21, 14 and 7 days.
5. **Scarcity:** few seats left at the price, or the last flight of the day.

**Rules of thumb:**
- At or below the low end of Google's typical range, or at the watch's low → **Buy now**.
- A holiday peak inside its window → **Buy now**; these fares rarely fall.
- In the typical range with more than 8 weeks to go → **Wait and watch**, with a target at the
  low end of the range and a "book by" date at the window's close.
- A US-touching fare 7 or more days out → buying now and keeping the 24-hour cancellation as a
  safety net is often the best of both.

Say the evidence in one line: "Buy now: $612 is under Google's typical $680 to $900, and fares
for this date have risen steadily for three weeks."
