# Price sources: what to query, which price to trust

Read by the `travel` skill before searching (SKILL.md Step 3). Sites change their pages and
URL formats; when one stops working, update this file.

## Which price to trust

**The deal page (the seller's own price for that fare) > the airline's site > Kayak and Google
Flights result cards > `vt flights` (Skiplagged / Kiwi search results).**

`vt flights` finds candidates; Kayak, Google Flights and the airline confirm them into option
records. A price never confirmed on a deal page is not shown. Kiwi.com is a fine *seller*, but
its search fare often excludes the bag (`no bag`) and sometimes shows combinations that are gone
on click. Never take a price from an ad card, a "from $X" header or a cheapest-deal headline.

## Sources

| Source | What it adds | How | Blind spots |
|---|---|---|---|
| **`vt flights`** (Skiplagged + Kiwi) | Whole grid of airports × days in one call; hidden-city; self-transfer; included bags; cheapest per airport pair and per day | `~/travel/code/bin/vt flights search ...` and `vt flights calendar ORIG DEST DAY` | No Southwest. Not the airline's own price. Skiplagged rate-limits to about 7 calls a minute, so a big grid takes 2 to 3 minutes |
| **Skiplagged and Kiwi MCP tools**, when registered | Single searches, Skiplagged's flex calendars and "anywhere" search | Call the tool directly | Same data as `vt flights` |
| **Kayak** | Main confirmation source: every seller's price per fare brand, bag rules, self-transfer bundles named | § Kayak below | Hides 2-stop results when the ≤1-stop filter is set: run once without it |
| **Google Flights** | Broad airline coverage including Southwest; the **price insight** (low / typical / high, typical range, history graph); market selection | `https://www.google.com/travel/flights?q=Flights%20from%20SFO%20to%20HEL%20on%202027-06-11%20one%20way&gl=US&curr=USD`. Add `%20returning%20YYYY-MM-DD`, `%202%20passengers`. Repeat with the destination country's `gl` | **The `?q=` search can misresolve codes** (an airport code read as a town of the same name) or fail outright: check the resolved airports on the page; fall back to Kayak. Multi-city needs the form. Never solve a CAPTCHA |
| **Airline sites** | The real price, fare rules, student fares, bag fees | The airline's own booking flow | One airline at a time |
| **Your loyalty program** | Award space and the cash co-pay | The program's site, signed in | Login needed |
| **Seats.aero** (free tier) | Award space for many programs | seats.aero | Cached and up to a day old |
| **Roame** (free tier) | Live award search, about 60 days ahead | roame.travel, free account | Free tier limited to about 60 days ahead |
| **PointsYeah** (free tier) | Broad award search with alerts | pointsyeah.com, free account | Program coverage varies |

## Kayak

**URLs**, with airport codes (comma lists work, `LON` means all London airports):
- `https://www.kayak.com/flights/SFO,OAK-HEL,ARN/2027-06-11?sort=price_a`
- `&fs=stops=-2` at most 1 stop; `stops=0` nonstop. **This hides 2-stop results**, so run once
  without it.
- **Multi-city and open-jaw:** chain the legs in the path, e.g.
  `https://www.kayak.com/flights/<ORIG>-<DEST>/<DATE>/<ORIG2>-<DEST2>/<DATE2>?sort=price_a`
  (for example SFO-HEL on 2027-06-11, then ARN-SFO on 2027-06-25).
  Check on the page that every leg was read as intended before trusting the price.
- Append to `fs` with `;`: `virtualinterline=-virtualinterline` hides self-transfer
  combinations; `landing=0000,1600@20270612` sets an arrival window; `takeoff=1700,2359` a
  departure window.

**Reading results** (they load in about 15 s):
- Expand a card's segment details to read times, connections and each leg's duration.
- Open the deal list with the card's "Select" button. It lists fare brands with their bag rules,
  then sellers with prices; the "Airline" label marks airline-direct.
- Self-transfer cards are labelled as such and name the only seller that bundles them.
- Kayak's page markup changes; if a selector stops working, read the page text instead.

## Ground transport

| Need | Source |
|---|---|
| **Connections and times, European rail and bus, door to door** | `vt trains journeys` (Transitous: most national operators, Flix, city transit; no fares; timetables to the next published change) |
| **Ferries, with fares** | `vt ferries search` (Ferryhopper; also its MCP tools when registered) |
| Rail fares | The operator's own site (bahn.de, sncf-connect.com, trenitalia.com, renfe.com, eurostar.com, and so on), with any railcard from the profile. Some block scripts: use the browser, never try to get around bot protection |
| Long-distance buses | flixbus.com, and airport shuttle operators |
| An unfamiliar region, every mode at once | rome2rio.com |
| Drive times | Google Maps at the actual time of day |
| Ride-hail | A live Uber or Lyft estimate; never assume a price |

## When a source fails

- Skiplagged returns HTTP 429: `vt flights` waits, retries and reports what was still refused.
  Fill the gap from Google Flights for those pairs rather than re-running the whole grid.
- Kiwi errors: Skiplagged and Google Flights cover the same ground, except self-transfer
  combinations.
- Google Flights blocked: the browser extension, then Kayak.
- "No results" can mean no service at all. Check the airport's Wikipedia page ("Airlines and
  destinations") before saying a route does not exist.
- **Never present a single scraped price as the market.** If only one source answered, say so
  and label the price low-confidence.
