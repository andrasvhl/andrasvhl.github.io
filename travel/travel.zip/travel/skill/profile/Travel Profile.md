---
type: profile
domain: travel
verified: YYYY-MM-DD
---

# Travel Profile

**<One line on how you travel: who pays, how hard you optimise for price, how much risk you
accept for a big saving.>**

**Read this when:** planning how to get anywhere, comparing flights or ground transport, or
judging whether a fare's drawbacks are acceptable. The `travel` skill reads it on every run.

How to fill it in: replace every `<placeholder>`. Write `unknown` where you do not know yet, so
the skill asks instead of guessing. Update `verified:` whenever you review the file; the skill
warns when it is old. Keep passport numbers, card numbers and passwords out of this file.

---

## 1. Bases and airports

Where trips start and end, and which airports count as home at each.

| Fact | Value | As of |
|---|---|---|
| Main base | <town or neighbourhood, country>. Airports <IATA, IATA> | <YYYY-MM-DD> |
| Second base | <town, country, e.g. where your family lives>. **<preferred airport, if any>** | <YYYY-MM-DD> |
| Alternatives from the second base | <airports within your drive limit that are fair game> | <YYYY-MM-DD> |
| Other places you often start from | <or "none"> | <YYYY-MM-DD> |

## 2. Getting to and from airports

Who can drive you, and what you have on the ground.

| Fact | Value | As of |
|---|---|---|
| Lifts | <who will drive you or collect you, from where, up to how many hours> | <YYYY-MM-DD> |
| Car | <own car where, or none> | <YYYY-MM-DD> |
| Other pickups | Varies by trip: **ask at the start of every trip** | |
| Rail discount | <railcard name, class and expiry, or none> | <YYYY-MM-DD> |

## 3. Points and payment

What you can pay with besides cash.

| Fact | Value | As of |
|---|---|---|
| Airline programs | <program names, or none> | <YYYY-MM-DD> |
| Frequent-flyer number(s) | <program: number>. Entered on every booking that earns in that program | <YYYY-MM-DD> |
| Balance | <miles or points per program> | <YYYY-MM-DD> |
| Status | <tier per program> | <YYYY-MM-DD> |
| Cards | <whether any card earns travel points or transferable points; no card numbers> | <YYYY-MM-DD> |
| Award search subscriptions | <e.g. Seats.aero Pro, or none> | <YYYY-MM-DD> |
| Student | <school and expected graduation, or not a student> | <YYYY-MM-DD> |

## 4. Trade-offs and risk appetite

How you weigh price against time, comfort and risk.

| Fact | Value | As of |
|---|---|---|
| Who pays | <yourself, employer, varies> | <YYYY-MM-DD> |
| Price vs time | <e.g. show every big jump with its drawbacks; no fixed $/hour rate> | <YYYY-MM-DD> |
| Transfers | <prefer fewer / don't mind> | <YYYY-MM-DD> |
| Hidden-city (skiplag) | <OK when no checked bag and the saving is really big / never> | <YYYY-MM-DD> |
| Self-transfer with checked bags | <OK / avoid> | <YYYY-MM-DD> |
| Connections | <warn under N h> | <YYYY-MM-DD> |
| Basic fares | <OK / warn if a checked bag is likely / avoid> | <YYYY-MM-DD> |
| Ultra-low-cost airlines | <fine / avoid> | <YYYY-MM-DD> |
| Arrival-day rule | <e.g. always also check flights arriving up to 2 days early> | <YYYY-MM-DD> |
| Airport buffer | <e.g. 1.5 h at the airport before departure> | <YYYY-MM-DD> |
| Sellers | <e.g. any seller, bundlers included; show the cheapest next to the cheapest airline-direct one> | <YYYY-MM-DD> |

## 5. Unknowns register

| Unknown | Blocks | How to resolve |
|---|---|---|
| <e.g. railcard expiry> | <e.g. pricing rail legs> | <e.g. check the card or the app> |

## 6. Countries visited

Optional. For visa forms that ask for travel history. Add each new country after a trip.

| Fact | Value | As of |
|---|---|---|
| Countries visited, last 10 years | <list by region> | <YYYY-MM-DD> |

## Maintenance

- § 2 "Other pickups" and § 3 balances change trip to trip; review the rest a few times a year.

## See also
- `reference/airports.md`: the ground leg from each base to each airport
