# Task schema

One note per task, all in one folder (`Inbox/`), told apart from other captures by a `type`
property. The skills, `vt todos` and any capture path you add (a hotkey, a phone shortcut) all
write this format. Copy this file into your vault and point the vault's `CLAUDE.md` at it.

Why a note per task: a note can hold attachments, Obsidian Bases (or the TaskNotes plugin) turns
a folder into an editable table, and reading many small notes is cheap for an agent as long as
bodies stay light.

## A capture

```yaml
---
type: action          # "" (untriaged) | action | dump | idea | reference ...
captured: 2026-11-02T08:40   # local time, to the minute
status: inbox
priority: 1-none
---

## Next action
- [ ] Next: <the text of the capture>
```

Every capture writes `priority` explicitly. An urgent capture writes all three of `urgent: true`,
`priority: 4-high` and `scheduled: <today>`: the date is what puts it in the ToDo view.

## Fields

| Field | Values | Written by | Meaning |
|---|---|---|---|
| `type` | `action` | every writer | it is a task |
| `status` | `inbox` / `open` / `in-progress` / `done` / `cancelled` | everyone | `inbox` is untriaged; `done` and `cancelled` are both closed, kept apart so dropped work never counts as done |
| `completedDate` | date | on close | when it was done or cancelled |
| `priority` | `1-none` / `2-low` / `3-normal` / `4-high` | `prioritise` | importance only; `4-high` is capped |
| `urgent` | `true` | capture, `prioritise` | felt urgency |
| `quadrant` | `urgent-important` / `important-not-urgent` / `urgent-not-important` / `neither` | `prioritise` | the 2x2; importance is the tier, urgency is asked |
| `prioritised` | ISO datetime | `prioritise` | when priority was last set, to tell stale from fresh |
| `timeEstimate` | minutes | `prioritise` | 15 / 60 / 180, or 360 with tag `needs-breakdown` |
| `startable` | `cold` / `run-up` | `prioritise` | fits a gap, or needs a protected block |
| `due` | date | anyone | **real deadlines only**; on a pending decision, the decide-by date |
| `scheduled` | date | `schedule-work` | the commitment: when it happens. Never a time |
| `waiting` | `true` / `false` | anyone | you are waiting on someone or something |
| `decision` | `pending` / `made` | `commit-to-action` | the real work is a choice; absent on most tasks |
| `projects` | list of wikilinks | `commit-to-action`, capture | `["[[Project]]"]`; the target note must exist |
| `tags` | `blocking-someone`, `needs-breakdown` | `prioritise` | someone waits on you; cannot be estimated until broken down |

Two axes, kept apart: `priority` is importance, `scheduled` is commitment. `prioritise` never
writes `scheduled`, `schedule-work` never writes `priority`. Neither touches a plugin's manual
sort order; drag order is yours.

## The body

```markdown
---
<frontmatter>
---

## Next action
- [ ] Next: <one physical step> (10 min)
- [ ] Then: <optional, ordered, at most three open lines>

<quoted fragment, facts, Source: [[Dump 2026-11-02 0815]]>

## Log
- Nov 3 · moved to Nov 5 · waiting for the quote
```

- **Every task opens with its next action, as a checkbox, directly under the frontmatter.** A task
  is well defined when it has an open `- [ ] Next:` step, or is waiting (`waiting: true` plus
  `- [ ] Waiting: <who>, <on what>`). Anything else gets flagged at triage.
- The open `Next:` line comes first in the block, above ticked steps.
- A step's own estimate goes at the end of its line, in parentheses.
- Updating a task means ticking and adding steps in that top block, never a second checklist
  further down.
- An optional `## Log` at the bottom: one line per change, newest last, `- <Mon D> · <what
  changed> · <source>`.
- Keep bodies light. Detail that matters goes in the note; long material goes in a linked note.

## The views

What `vt todos` prints, and what a cockpit view in Obsidian should filter on:

| View | Filter |
|---|---|
| ToDo | (`due` set, or `scheduled` <= today) and not closed |
| Triage | `status: inbox` |
| Unscheduled | no `due`, no `scheduled`, not `inbox`, not closed |
| All | not closed |

Priority is deliberately not a way into ToDo: a date expires, a priority never does.
