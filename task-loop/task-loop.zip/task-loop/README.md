# task-loop

Five Claude Code skills and a small script that run a personal task system out of an Obsidian
vault, one task per note. The loop has four steps, each its own skill, deliberately kept apart:

1. **`dump`**: you talk, Claude listens. It asks two questions (what are you undecided about, what
   are you avoiding), then stays silent while you empty your head, runs a blunt sweep of cues, and
   writes everything verbatim into a dated note. It creates no tasks.
2. **`commit-to-action`**: turns one dump into task notes, one per thing you named, each with a
   next physical step as a checkbox. It proposes the whole set in one table and writes only after
   you confirm. Worries, horizon decisions and stale items are listed as "not becoming tasks", never
   dropped silently.
3. **`prioritise`**: you decide what matters, the skill records it and enforces a cap (9 high, at
   most 3 per live priority). It asks urgency as one word per task instead of guessing it from
   dates, flags tasks without a next step, and sizes the high ones.
4. **`schedule-work`**: decides when. It reads your calendar, asks what is missing from it before
   planning, states the capacity gap in hours, plans to 80% of free time, puts
   important-not-urgent work first, and creates calendar blocks once you approve.

Plus **`obsidian-todo`**, for "what are my to-dos" and "add X to my list" at any time, backed by
`vt todos`, which prints the same views as your task cockpit (ToDo, Triage, Unscheduled).

The method came out of a few months of daily use and the skills keep the reasoning next to each
rule, so you can see why a rule exists before you change it.

## Requirements

- Claude Code.
- An Obsidian vault. The skills only read and write markdown; Obsidian itself is optional, but the
  TaskNotes community plugin and Bases make the task folder a
  usable table on desktop and phone.
- Python 3.9 or newer for `vt todos` (stdlib only).
- For `schedule-work`'s calendar part: a calendar MCP server connected to Claude Code (for example
  a Google Calendar one). Without it, it still plans and prints the week as text.

## Install

```bash
# from the unzipped task-loop folder

# 1. the script, on your PATH
mkdir -p ~/.local/share/task-loop ~/.local/bin
cp code/todos.py code/vt ~/.local/share/task-loop/
ln -sf ~/.local/share/task-loop/vt ~/.local/bin/vt
echo 'export VAULT_PATH="$HOME/path/to/vault"' >> ~/.zshrc     # see config.example.env
vt todos                                                      # prints three empty views

# 2. the skills
mkdir -p ~/.claude/skills
cp -r skills/* ~/.claude/skills/

# 3. the notes the skills read, into your vault
mkdir -p "$VAULT_PATH/Inbox" "$VAULT_PATH/Areas" "$VAULT_PATH/_system/scheduling"
cp "templates/North Star.md" "$VAULT_PATH/Areas/"
cp templates/working-conditions.md "$VAULT_PATH/_system/scheduling/"
cp docs/task-schema.md "$VAULT_PATH/_system/"
```

Skills in `~/.claude/skills/` are available in every Claude Code session on that machine. To
scope them to one vault instead, copy them into `<vault>/.claude/skills/`. Restart Claude Code
(or start a new session) and they show up; Claude picks them by their descriptions, so "let's do
a dump" is enough.

**Then fill in the two templates.** `North Star.md` holds your current priorities, what you are
explicitly not doing, your big open decisions and your tie-break rules. `working-conditions.md`
holds when you work, your peaks and dips, standing calendar blocks, your calendars with their IDs,
and how blocks should be written. The skills read both every run and tell you when a `revisit:`
date has passed. Nothing personal is hardcoded in the skills.

**Tell the vault where things are.** If your folders differ from the defaults, add this to the
vault's `CLAUDE.md` and edit the paths; every skill checks it first:

```markdown
## Task loop
- Tasks: `Inbox/` (schema: `_system/task-schema.md`)
- Priorities: `Areas/North Star.md`
- Working conditions: `_system/scheduling/working-conditions.md`
- Projects: `Projects/<Name>/<Name>.md`, areas: `Areas/`
```

## Usage

A typical morning: "dump", talk for five minutes, answer the sweep, "anything missing?" no. Then
"commit", review the table ("all except passport and gym"), done. Once or twice a week,
"prioritise" and "plan my week". Any time: "what's due today?", "add call the bank to my list".

```bash
vt todos                    # ToDo + Triage + Unscheduled
vt todos --view todo        # todo | triage | unscheduled | all
vt todos --json             # what the skills read
vt todos --add "Renew passport" --due 2026-12-01 --project "Admin"
```

## Things worth knowing

- **Rows are keyed by short keywords, never numbers**, because dictation tools renumber lists.
  Answer "passport: high, urgent" rather than "3: high".
- **`due` means a real deadline; `scheduled` means a commitment.** Only `schedule-work` sets
  `scheduled`. A passed `scheduled` date keeps the task in ToDo until it is re-planned, which is
  why the weekly run sweeps the past first.
- **`schedule-work` never deletes calendar events.** It tells you which to remove.
- The skills record their own improvements: push back after a run and they propose concrete
  changes to the skill file, never mid-run.

## Layout

```
skills/      dump, commit-to-action, prioritise, schedule-work, obsidian-todo
code/        todos.py (the reader/writer) and vt (its entry point)
templates/   North Star.md, working-conditions.md: blank, for you to fill in
docs/        task-schema.md: the note format every writer follows
config.example.env
```

## License

MIT, see `LICENSE`.
