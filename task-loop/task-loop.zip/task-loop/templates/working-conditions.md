---
type: reference
revisit: 2026-12-31
---

# Working conditions

When work can actually be placed. `schedule-work` reads this before proposing a week and treats
it as hard constraints; when you tell it something different during a run, your answer wins and
it proposes an update here. The telegram-bridge package reads the **Sleep** row for its quiet
hours, so keep that row's wording (Wake ... weekdays, ... weekends, lights off ...).

Every row carries an expiry. A condition without one gets carried silently into a week where it
is false. Replace everything in angle brackets; the example values parse as they stand.

## The day

| What | When | Until |
|---|---|---|
| Sleep | **Wake 07:00-07:30 weekdays, ~08:30 weekends.** Wind-down from 22:30, lights off ~23:30. | <date> |
| Working day, weekdays | <09:00-18:00, about 6 focused hours> | <date> |
| Working day, weekends | <10:00-13:00 on one day, the other off> | <date> |
| Peaks | <09:00-12:00 and 17:00-19:00>: demanding, `run-up` work goes here | <date> |
| Dip | <13:30-16:00>: mechanical work, admin, errands | <date> |
| Lunch | <12:00-13:00>, counts as used time | <date> |
| Dinner | <19:00-20:30>, no tasks | <date> |
| Sport | <runs Tue/Thu 07:00, 1 h door to door> | <date> |
| Commute | <30 min each way on office days> | <date> |

## Standing blocks

Recurring events already in the calendar. `schedule-work` fills them rather than creating new
blocks, and never moves or deletes them.

| Block | When | Calendar | Holds |
|---|---|---|---|
| <Big rocks> | <Thu 09:00-13:00> | <main> | <about 3.5 h of big-rock work> |
| <Weekly review> | <Fri 16:00-16:30> | <main> | <the schedule-work run> |

## Calendars

Re-checked at every run. A calendar that appears and is not listed here is a question.

| Calendar | ID | Role | Blocks time? | Write? |
|---|---|---|---|---|
| <Main> | <you@example.com> | <meetings, invites, important work> | yes | yes |
| <Focus> | <calendar id> | <solo work blocks> | no (shown free) | yes |
| <Shared family> | <calendar id> | <someone else's plans; never counts as your time> | no | read |
| <Holidays> | <feed id> | <days off> | no | read |

## Block conventions

How `schedule-work` writes blocks. Change to taste.

| What | Calendar | Availability | Title |
|---|---|---|---|
| Important work (`4-high`, big rocks) | <Main> | busy | starts with `!` |
| Other task work, batches, buffers | <Focus> | free | named by its contents |
| Committed personal time (travel, appointments) | <Main> | busy | plain |
| Provisional holds | <Main> | busy | starts with `Hold:` (ignored when planning) |

Every block's description ends with `Task: obsidian://open?vault=<VAULT_NAME>&file=<path>` for
each task it holds. The time zone is always set explicitly: <Europe/Berlin>.

## Rules of the week

Standing rules a plan must not break. `schedule-work` names any rule a plan cannot meet instead of
dropping it silently.

- <e.g. "At least two evenings with friends.">
- <e.g. "No work after 21:00.">
- <e.g. "One evening a week with no screens.">
