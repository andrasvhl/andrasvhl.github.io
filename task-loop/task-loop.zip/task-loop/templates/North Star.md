---
type: reference
revisit: 2026-12-31
---

# North Star

What matters right now. The task-loop skills read this note: `dump` turns each live priority
into a sweep cue, `commit-to-action` uses the priorities to pick projects and keeps horizon
decisions out of the Inbox, `prioritise` caps high-priority work per live priority, and
`schedule-work` uses the horizon and the decision rules.

Keep it short and current. Set `revisit:` to the date this stops being true; the skills will say
so when it has passed. Replace every line in angle brackets.

## Horizon

<The window this note covers, and what ends it: "Nov 3 to Dec 19, until the winter break".>

<Rough capacity in that window: "about 30 focused hours a week; the rest is meetings".>

## Live priorities

The cap unit for `prioritise`: at most **3** `4-high` tasks per priority, **9** in total. Change
the numbers here if yours differ.

1. **<Priority>**: <one line on what winning looks like this horizon>
2. **<Priority>**: <...>
3. **<Priority>**: <...>

## Not this horizon

Things that are real but explicitly not now. Tasks belonging here get `priority: 1-none`.

- <...>

## Horizon decisions

The big open choices. They are never tasks; their component steps are.

- <Decision>: <what it depends on, decide-by date if any>

## Decision rules

Tie-breaks the skills apply when two things compete for the same hours.

- <e.g. "Deadlines with other people beat solo work.">
- <e.g. "Emotionally demanding work goes in the morning.">
- <e.g. "When a big rock needs time, prep gets shorter rather than dropped.">
