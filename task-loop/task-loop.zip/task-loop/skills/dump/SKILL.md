---
name: dump
description: Run a verbal brain dump, the offloading half of a daily check-in. Use whenever the user says "dump", "brain dump", "let's do a dump", "do a check-in", "empty my head", "here's what's on my mind", or starts listing things they are worried about forgetting. Captures everything they say verbatim into a dated note in the Obsidian Inbox, offers a blunt cued sweep afterwards, and stops. Does NOT create tasks; that is the separate commit-to-action skill.
---

# Dump

The offloading half of the daily check-in. The other half is `commit-to-action`, which turns a
dump into real tasks. **They are deliberately separate. This skill never creates tasks.**

Paths: the vault is the working directory. The Inbox is `Inbox/` and the priorities note is
`Areas/North Star.md`, unless the vault's `CLAUDE.md` says otherwise under "Task loop".

## What this is for

**An offloading exercise, not a task-collection exercise.** What the user is buying is an emptier
head; the list is a byproduct. What goes in is "things on my mind that make me anxious and that I
need to do", so anxiety is the retrieval cue, and that drives every rule below.

1. **Completeness beats precision.** 90% captured roughly is worth far more than 60% captured
   cleanly. Never trade coverage for structure.
2. **Not everything said is a task.** Some items are worries with no action, some are decisions,
   some are already handled. Do not reshape any of it. Sorting happens in `commit-to-action`.

## Hard prohibitions

**Throughout Phases 1 and 2, you must not:**

- ask a clarifying question about anything said
- comment on, react to, or evaluate any item
- offer advice, solutions, encouragement or reassurance
- rank or reorder items
- create any task note, or edit any existing note
- suggest what they might have meant
- respond at length to an interesting item

Default helpful behaviour destroys a dump. Answering item three while they are still trying to
remember item seven costs them item seven. **Silence is the feature.** The most common failure of
this skill is being useful too early. The recall aids in Phase 1 and the already-covered markers
in Phase 2 are the only exceptions, and both serve completeness, not organisation.

## Phase 1: freeform dump

**Lead with two questions, then go freeform**, all in one message:

> **1. What are you undecided about?** Include anything that looks like a reply or an RSVP but is
> really a decision you have not made yet.
> **2. What are you avoiding that's important?**
>
> Then freeform: whatever else is on your mind, in any order.

Why these two: undecided items are quiet by construction. They do not feel like tasks, they feel
like fog, so a freeform dump rarely reaches them, and a pile of unmade decisions often drives
background anxiety more than the amount of work does. Avoided items are the opposite case:
emotional resistance rather than a missing choice. Do not merge the two questions. Two is the
ceiling: do not add a third.

Then **stay out of the way.** People dictate in bursts, so expect several messages. Between bursts
acknowledge in a few words, never referencing content: `Got it.` `Keep going.`

### Two recall aids, offered only when they stall or ask

- **A. Running readback.** A compact bulleted list of what has been captured so far, in their
  words, in the order said. No grouping, no interpretation. It answers "what have I already said"
  by letting them scan instead of re-derive.
- **B. Broad pointers.** Wide buckets meant only to shake something loose:
  > people · commitments · money · body · travel · home · work · anything with a date

Never interrupt a flowing dump with them.

### Ending Phase 1

Ask explicitly; do not wait for "done" (it rarely comes):

> Ready for the sweep?

They can keep going, or skip the sweep and go straight to Phase 3.

## Phase 2: cued sweep

**Present all cues at once, as one list keyed by short bold keywords**, so they can answer
"avoiding: ..." and work down the list in one pass. Keywords, not numbers: dictation software
renumbers lists.

The freeform dump catches what is loud. The sweep catches what is quiet, and the quiet items are
often what generates the background anxiety, precisely because they never surface on their own.

**Build the list:**

1. **Read the priorities note** (`Areas/North Star.md`, section "Live priorities") and use each
   current priority as a cue. Never hardcode them; reading the file keeps the sweep current. If
   the note's `revisit:` date has passed, say so in one line and continue.
2. **Then always these six:**
   - **undecided**: what are you still undecided about?
   - **waiting**: who's waiting on you?
   - **promised**: what have you promised someone?
   - **avoiding**: what have you been avoiding?
   - **admin**: money and admin
   - **deadlines**: anything with a deadline in the next 7 days

**Mark what they already covered.** Against any cue they have already spoken to, append a few of
their own words, enough to recognise. They then add only what is new. This never changes what gets
written.

**Be blunt.** Do not soften or apologise for the cues. "What have you been avoiding?" is the
highest-yield and least comfortable question in the skill; ask it plainly.

Same prohibitions throughout: capture the answers, react to none of them.

## Phase 3: write, read back, stop

**1. Write the transcript** to `Inbox/Dump YYYY-MM-DD HHMM.md`:

```yaml
---
type: dump
captured: 2026-11-02T08:15
status: inbox
---
```

Then their words under two headings, `## Free dump` and `## Sweep`, each sweep block labelled with
the cue that pulled it. Keeping the phases apart is provenance: sweep items are the ones they
*forgot*, and over time that shows what chronically drops out of their head.

**Verbatim means verbatim.** You may repair obvious dictation punctuation and proper nouns (below),
nothing else. Never reword, reorder, summarise, merge or drop anything, including items that seem
trivial, contradictory or already handled. `commit-to-action` re-reads this file.

**Repair garbled proper nouns, and declare every repair.** Repair a name only when a known vault
entity (a project folder, an area note, a person note) makes it unambiguous; otherwise write what
was said. List every repair at readback (`Repaired: "Acme Robotix" -> Acme Robotics`) so they can veto it.
Never treat the vault as more authoritative than the user: when they correct a name, fix the
transcript and grep the vault for the wrong spelling, since the source is often a note.

**Duplication between the two sections is fine.** Do not deduplicate; `commit-to-action` resolves
overlaps.

**2. Read back** a flat bulleted list of everything heard, in their words, then the repair line if
any, then exactly one question:

> Anything missing?

It is the fidelity check and the moment they get to let go of the list. Add anything new and
rewrite the note.

**3. Stop.** Offer in one line that `commit-to-action` is the next step, then wait. Do not run it.

## Notes

- **Email, chat and other sources do not feed this skill.** The dump stays purely what is in the
  user's head; reviewing an inbox turns it into an admin session. External sources are inputs to
  `commit-to-action`.
- Dumps accumulating in `Inbox/` is fine. `status: inbox` marks a dump unprocessed;
  `commit-to-action` sets it to `done`.
- Task schema: `_system/task-schema.md` (copied there from the package on install).

## Improving this skill

When the user pushes back on how a run went, treat it as design input, not a correction to apply
silently: turn it into concrete options and let them choose. Ground proposals in what happened in
the run, offer the review after a real run, and record each adopted change here with its date and
reason. Never edit the skill while a run is in progress; collect the changes and apply them after.
