---
name: obsidian-todo
description: Instantly list or add Obsidian to-dos by running a local script against Inbox/ (notes whose type property is action). Prints the same views as the task cockpit (ToDo / Triage / Unscheduled). Use whenever the user asks for their to-dos, tasks, what's on their plate, what's due, what needs triaging, or what's sitting unscheduled ("what are my to dos?", "anything due today?"), and whenever they ask to add, capture or be reminded of a task ("add X to my list", "remind me to Y", "I need to do Z").
---

# Obsidian to-do

Runs `vt todos` (the task-loop package's `todos.py`) against `Inbox/`, the vault's task folder
(`type: action` notes). It reads every note's frontmatter in one pass for listing, and writes new
notes in the task schema (`_system/task-schema.md`), so "add a to-do" lands where every other capture
path writes. Stdlib Python only.

The vault is `VAULT_PATH` (default `~/vault`); the task folder is `TASKLOOP_INBOX` (default
`<vault>/Inbox`).

## The views

| View | Filter | Meaning |
|---|---|---|
| `todo` | (`due` set, or `scheduled` <= today) and not closed | the daily driver; a date is the only way in, priority deliberately is not (it never expires) |
| `triage` | `status: inbox` | captured, not yet triaged |
| `unscheduled` | no `due`, no `scheduled`, not inbox, not closed (recurring: not completed today) | the Someday bucket |
| `all` | not closed | everything live, flat |

Closed is `status: done` or `cancelled`. Status values: `inbox` (untriaged), `open`,
`in-progress`, `done`, `cancelled`. Priority: `1-none`, `2-low`, `3-normal`, `4-high`. `waiting`
is a boolean (waiting on a person or event), not a status; a waiting task stays in ToDo.

If you keep a cockpit view in Obsidian (Bases or TaskNotes), keep its filters identical to these.
Two definitions of "active" is the failure this reader exists to prevent.

## Listing

```bash
vt todos                    # ToDo + Triage + Unscheduled
vt todos --view todo        # one view: todo | triage | unscheduled | all
vt todos --json             # all four views, machine-readable
```

`--json` rows carry `name`, `status`, `urgent`, `waiting`, `priority`, `due`, `scheduled`,
`recurrence`, `complete_instances`, `project`, `timeEstimate` (int or null), `quadrant`,
`startable`, `tags`, `decision`, `path`. If a skill gains a field it places by, add it to the
reader in the same change, so nobody builds a second reader.

## Adding

```bash
vt todos --add "Text of the task" [--urgent] [--due 2026-11-12] \
  [--scheduled 2026-11-04] [--priority 3-normal] [--project "Home"] [--next "First step"]
```

Only `--add` is required. The note gets `type: action`, `captured`, `status: inbox`, an explicit
`priority` (`1-none` by default), and a body opening with `## Next action` /
`- [ ] Next: <text>`. If the text is not a physical step yet, sharpen that line after adding.

- `--urgent` writes `urgent: true`, `priority: 4-high` **and `scheduled: <today>`**. The date is
  what gets it into ToDo; the flag alone would not.
- `--due` is for **real deadlines only**. `--scheduled` is "the day I intend to work on it"; an
  unfinished item stays in ToDo tomorrow instead of showing overdue.
- `--project` is the exact title of an existing project note.

## After running

**Listing:** relay the script's grouping (ToDo, Triage, Unscheduled). Do not re-rank or
re-categorise. If the user wants to act on several tasks, key them with short keywords, never
numbers, and echo back by keyword plus title. Marking a task done or moving it also means checking
for future calendar blocks that point at it (their description carries a `Task:` link) and moving
or deleting them in the same step, with the user's say-so.

**Adding:** confirm in one line (title, plus any flags). Do not ask for fields the user did not
mention; capture never blocks. One exception: if the task obviously belongs to an existing project
note (one `ls` of `Areas/` and `Projects/`), set `--project`; if it is not obvious, leave it and
say "no project set".

## Gotchas

- `status: inbox` means untriaged, not an ordinary active task; it is kept out of Unscheduled.
- The frontmatter parser is line-based: `key: value` and block lists (`projects:` then indented
  `- "[[X]]"`). Nested maps and multi-line scalars will not parse.
- A note's body holds detail the script does not print; read the file for that.
