---
name: schedule-work
description: Decide when the prioritised Obsidian tasks actually happen, writing `scheduled` across the coming week to week and a half and, once the plan is approved, calendar blocks. Use when the user says "schedule", "schedule my work", "plan my week", "when am I doing this", "let's do scheduling", "what does my week look like", or asks how the next few days should go. Reads the calendar, asks what is missing from it, states the capacity gap in hours, protects important-not-urgent time. Does NOT decide what matters; that is prioritise.
---

# Schedule work

The last act of the loop: `dump`, `commit-to-action`, `prioritise` (what matters), then this
(**when it happens**).

Named `schedule-work`, not `schedule`, so it never collides with a scheduling skill for cron-style
routines.

Paths: `Inbox/`, `Areas/North Star.md` and `_system/scheduling/working-conditions.md`, unless the
vault's `CLAUDE.md` says otherwise under "Task loop". **The calendars, block conventions and
standing blocks are the user's and live in working-conditions, never in this file.** Read them
there.

Needs a calendar tool (any calendar MCP server that can list calendars, list events and create
events). Without one, run every pass except the block writes, and output the plan as text.

## Scope: two axes, kept apart

| Axis | Field | Set by |
|---|---|---|
| Importance | `priority` | `prioritise` |
| Commitment | `scheduled` | **this skill** |

**Writes:** `scheduled` (a date, never a time), `status: done` when Pass 0c establishes on the
user's word that past work was finished but never ticked, and calendar events, **only after the
user approves the plan**. Do not write events as a side effect of planning.

**Never writes** `priority`, `quadrant`, `timeEstimate` or a plugin's manual sort order. **Never
deletes calendar events**: say which to remove and why; deleting is the user's.

## What `scheduled` does to the cockpit

- The ToDo view is "`due` set, or `scheduled` <= today". A task scheduled for next Thursday does
  not appear until Thursday, so scheduling ahead is safe.
- Unscheduled (Someday) is "no due, no scheduled". Writing `scheduled` removes a task from
  Someday. Do not scatter dates to look productive; each date is a commitment that will surface.
- **A passed `scheduled` date never expires.** An over-full week silently piles up in ToDo as
  arrears. This is the main way this skill can make things worse, and Pass 0b counters it.

## Horizon

**Today through about today + 10 days, at date granularity.** Bound it by the North Star note's
"Horizon" if that ends sooner (a trip, a deadline).

## Pass 0: read the world, one pass each

1. **Tasks:** `vt todos --json`. Same definition of active as the cockpit; never build a second.
2. **The North Star note** ("Horizon", "Live priorities", "Decision rules") and
   **working-conditions** (working day, peaks, standing blocks, calendars, block conventions,
   expiry dates). If either `revisit:` date has passed, say so in one line and ask rather than
   planning against it.
3. **The calendar**, read-only, for the whole horizon: list calendars first (they add calendars),
   then events on **every** calendar in the working-conditions roster, not just the default. A
   calendar not in the roster is a question: what is it for, does it block? Unanswered
   invitations and provisional holds (per the conventions, e.g. titles starting `Hold:`) get one
   line each asking whether they count. **Holds are not commitments**; do not plan around them
   unless the user says so.

If the calendar cannot be read, say so plainly and continue; never plan blind silently.

## Pass 0b: sweep the past first

List every task whose `scheduled` date has passed. For each: re-place it, or clear the date back
to Someday. Arrears are real load; capacity computed without them is fiction.

## Pass 0c: reconcile past blocks against task status

Read the calendar back to the last run and line up each past block with its task, as one table:

```
| Calendar block              | Task                  | Vault says       | Verdict                       |
|-----------------------------|-----------------------|------------------|-------------------------------|
| Tue 09:30-11:00 draft report | Draft the Q3 report   | done             | ok, consistent                |
| Tue 14:00-15:00 book trains  | Book trains to Lyon   | open             | ? did this block happen?      |
| (no block)                   | Reply to the landlord | open, due Mon    | ?                             |
```

- `ok` needs no answer; it shows the check ran.
- `?` is the ask, answered in one pass. **Ask, do not infer.**
- `x` (did not happen) only where something in the run proves it, never on a hunch.
- Include tasks whose `scheduled` passed with no block (Pass 0b folded in).
- Marking a task done on the user's answer is recording a fact; say which you closed.
- **Look forward too:** a future block whose task is now done, or moved, is stale. Every block's
  description carries a `Task:` link (below), so search the horizon for it. List stale blocks for
  the user to delete.

## Pass 1: ask what is missing from the calendar (a gate)

**Do not plan past this.** A thin calendar does not mean an empty life; it means the calendar
under-represents reality, and planning against it gives a fantasy with confident numbers.

**Pass 1a, the shape of the day, asked alone first**, as a structured list, compared with what
working-conditions records (their answer wins; say the file is stale):

| | Question |
|---|---|
| **weekdays** | when does the day start and end, and when is lunch? |
| **weekends** | same, and how much of a weekend day is work? |
| **travel** | anything in the horizon that eats days, including transfers and the days either side? |
| **sport** | what does training cost in hours, and when? |
| **appointments** | anything fixed with another person in it? |
| **weekday shape** | mornings for what, evenings free or working? |
| **weekend shape** | the same, separately |

Weekdays and weekends separately: a single question flattens 6 hours and 3 into one wrong number.
Then multiply out loud: "N hours a day, M days: H hours gross before commitments."

Answers that invalidate the whole plan (the day starts at 09:30, training every evening) must come
before answers that only add detail.

**Pass 1b, what is in the day.** "Your calendar has N events between today and <date>. What is
real but not in there?" Then one blunt list: fixed commitments, travel, family and household,
social plans already agreed, anything in the next 10 days they already know will happen.

**Committed time missing from the calendar becomes a block,** proposed with the work blocks and
written after approval. A commitment held only in this conversation is gone when it ends. Travel
eats more than the flight: block the transfer and the days either side. Do not duplicate what is
already there.

**Durable answers go to working-conditions,** each with an expiry ("day ends 18:30, until Nov 15").
Propose the write in one line at the end; do not slip it in.

**Pass 1c, something to look forward to.** "Is there something this week or next you are
genuinely looking forward to? If not, let's put one in." If yes, check it is on the calendar. If
no, propose one concrete thing (a dinner, a call with a named friend, a film). It goes before the
capacity report because it has to compete for real hours.

## Pass 2: the capacity report, in hours, before any placement

Four numbers, plainly:

1. **Committed hours** in the horizon: calendar plus Pass 1.
2. **Free hours**, per day and in total.
3. **Work outstanding**, from `timeEstimate`, with `4-high` broken out.
4. **The gap, as a rate**, because a rate is what can be felt: "35 h of high-priority work, 20 h of
   it due within 8 days: 2.5 h a day, every day, on high work alone."

**The 80% rule.** Plan at most 80% of free hours; the last fifth is the plan's tolerance for being
wrong. State both numbers ("49 h free, so this plan stops at 39 h"). When a request pushes past
the ceiling, say what has to come out; the user can spend the reserve deliberately, never by
accident. **Block the reserve too**, as `Buffer` blocks spread across the days (an overrun on
Tuesday cannot use a Friday buffer), shown as free so the calendar stays bookable.

Then stop and let them react. The honest number sometimes changes what they want scheduled.

## Pass 2b: name the week's big rocks first

Before placing anything, name **at most four or five big rocks**: the work that would make the
week a failure if it slipped, from the `important-not-urgent` items and the hardest deadlines.
More than five qualifying is itself the finding: ask what drops. Each rock gets a done-by date and
a definition of done; say when a rock depends on someone else. **Check deadlines against travel:**
pull deliverables due during or just after a trip to before departure.

## Pass 3: place, in this order

The week is built around the top two quadrants; everything else fills the gaps.

1. **`urgent-important`, then `important-not-urgent` (protected blocks).** Important-not-urgent
   work loses by default to louder noise unless it is actually scheduled. Nothing with a deadline
   will ever lose to it, which is why it goes first.
2. **Breakdown sessions for `needs-breakdown` items.** Never schedule one whole: its `360` is a
   floor, not an estimate. Schedule a 45-60 minute session to break it down, and say so in the
   block.
3. **Deadline-forced items.** `scheduled` on or before `due`. Where a deadline cannot be met with
   the hours available, **say it will be missed** rather than placing it on the due date and
   calling it planned.
4. **`run-up` work into peak blocks** (working-conditions says when the peaks are). Never into the
   dip.
5. **`cold` work into the gaps,** with `blocking-someone` tasks at the front of the queue.
6. **Stop when the hours run out,** not the list. Everything left goes on the deferred list by
   name.

Placement rules:

| Field | Effect |
|---|---|
| `startable: run-up` | a protected block in a peak |
| `startable: cold` | fits a gap; unset with `timeEstimate <= 30` counts as cold, otherwise ask, one word, only for tasks placed this run |
| `timeEstimate` | block length x 1.5, rounded up to 15 min (estimates run short) |
| `quadrant: urgent-not-important` | batch into one low-energy slot, never a peak |
| `due` | hard ceiling on `scheduled` |
| `priority` | ordering within a competing slot only |
| `waiting: true` | never placed as work; its `scheduled` is the chase date; listed separately |

**Sub-hour tasks get no block of their own; batch them** into one block whose title names the
items joined with `+` ("Landlord email + passport photos + gym cancel"), never just "Admin", with
the full task titles in the description.

**A booking deadline is not the travel date.** A "book the flight" task due on the day of travel
is useless; this skill may move such a `due` earlier.

If the run starts mid-day, propose and create today's blocks first, then the rest as one list.

## Pass 4: write `scheduled`

Show the placement as one list grouped by day, keyed by short keywords (never numbers), and wait.
Then write `scheduled: YYYY-MM-DD` on the confirmed tasks. Nothing else in the notes changes.

## Pass 5: blocks, then the report

**Create the calendar events once the user approves**, following working-conditions' block
conventions (which calendar, busy or free, title prefixes). Two rules regardless of convention:

- **Every block links to its task**: the description ends with one line per task,
  `Task: obsidian://open?vault=<VAULT_NAME>&file=<URL-encoded path without .md>`. The link runs
  one way, event to task; the note stores no event id (ids go stale on every move).
- **Always set the time zone explicitly** and say which one. A block written in the task note's
  language, never translated.

Then the closing report:

- **The week's important goals first**, three to five lines: what they should be able to read in
  five seconds and know the week points the right way.
- **What got scheduled**, by day, with the daily hour load.
- **What did not**, by name, one-line reason each. **Not optional.**
- **Waiting items**, listed separately with their chase dates.
- **The gap**, restated in one line.
- **Two gut-check questions:** "Does this week match the priorities you have right now?" and
  "Zooming out, are the things that matter most on track, not just this week's slice?" If either
  answer is no, the plan is wrong, not the user.

## Pass 6: reconcile and confirm before ending

A session ends when the calendar and the vault say the same thing and the user has said the plan
works. Plans change several times mid-session, and each change can invalidate a date already
written.

1. For every task given a `scheduled` date this session, confirm a block still exists that day.
   Moved block: rewrite `scheduled`. Dropped block: re-place or clear, with the user. Multi-session
   tasks keep `scheduled` at the start date.
2. **Report drift even when there is none:** "23 notes carry dates; all 23 match a block."
3. Ask, as a small set: "Does this schedule work? Be honest. What's missing? Are the important
   things in there?"

Name what needs their hand: events to delete, recurring instances that collide with an
appointment, days over their stated limits.

## Improving this skill

When the user pushes back on how a run went, treat it as design input: turn it into concrete
options and let them choose. Record each adopted change here with its date and reason. Never edit
the skill while a run is in progress. Expect Pass 1's questions and the block conventions in
working-conditions to need tuning after the first real runs.
