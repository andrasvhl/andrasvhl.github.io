---
name: prioritise
description: Work through the open Obsidian tasks and decide what actually matters, writing priority, urgency (quadrant), effort and startability. Use when the user says "prioritise", "prioritize", "let's do priorities", "what matters", "run prioritisation", or asks to sort out their backlog. Decides importance only; it never schedules anything or picks what they do today, which is schedule-work. The user dictates, the skill records and enforces the caps.
---

# Prioritise

The third act of the loop: `dump` empties the head, `commit-to-action` makes tasks, this decides
**what matters**, `schedule-work` decides **when**.

Paths: `Inbox/` and `Areas/North Star.md`, unless the vault's `CLAUDE.md` says otherwise under
"Task loop". Schema: `_system/task-schema.md`.

## Scope: two axes, kept apart

| Axis | Field | Set by |
|---|---|---|
| Importance | `priority` | **this skill** |
| Commitment | `scheduled` | `schedule-work` |

**Writes:** `priority`, `quadrant`, `timeEstimate`, `startable`, `prioritised`, the tags
`needs-breakdown` and `blocking-someone`, and `due` only where a genuine deadline surfaces.

**Never writes** `scheduled` (one exception: timing the user dictates in the same breath, "high,
and do it today", is recorded and said in one line) and never a manual sort order a plugin keeps
(drag order is the user's).

## The caps

**9 `4-high` globally, at most 3 per live priority** in the North Star note's "Live priorities".
Change the numbers in the North Star note if yours differ; the limit is the mechanism, the digit
is arbitrary.

The cap unit is a live priority, not a folder: a "Personal" folder can hold the user's top
priority and a pile of RSVPs, and capping them together makes no sense.

**Warn, never refuse.** "That's 12; which 3 go to normal?" A cap that can be exceeded silently is
not a cap; a skill that overrules the user is worse.

## The scale

| Value | Meaning |
|---|---|
| `4-high` | the capped top tier, scarce by construction |
| `3-normal` | real work, not now: the pool that refills high when slots open |
| `2-low` | real but weak |
| `1-none` | explicitly not this horizon (ties to "Not this horizon" in the North Star note) |

## Pass 0: stale highs first

List every `4-high` whose `due` or `scheduled` has passed. They hold cap slots whether or not they
are still true. Ask: still high, lower, or re-date? If the North Star note is stale (`revisit:`
passed), enforce only the global cap and say the per-priority cap cannot be checked.

## Pass 1: fast sort, as a table

Read all tasks once: `vt todos --json`. Present every unprioritised task as **one table**, every
input needed to judge it as a column, answer columns blank:

| Key | Task | Area | Due | Flags | Tier | Urgent? | Needs date? |
|---|---|---|---|---|---|---|---|

- **Key:** a short bold keyword from the title, unique. Never numbers or letters (dictation
  renumbers them). Reuse the keys for the whole session.
- **Due** is shown so they do not judge importance against date pressure they cannot see, and read
  "has a deadline" as "is important".
- **Flags:** only what changes the judgement: overdue, decision, waiting, untriaged, "gates X",
  and the next action (below).
- **Urgent** is one word, asked, never inferred from a date (see Quadrant).
- **Needs date?** yes/no for every tier, not only highs. Concrete dates come in Pass 2.

**Accept natural answers, store only real values.** "High / medium / low" is fine; write
`4-high` / `3-normal` / `2-low` / `1-none`, and echo the stored value ("medium -> `3-normal`") so a
bad mapping shows at once.

**Check the next action on every row** (the rule is in `commit-to-action`; this pass verifies).
Flags show `next: <a few words>` when the note has an open `- [ ] Next:` line, or
**`no next action`** when it has none. Captures from quick-add paths arrive without one, and this
is the one pass that walks the whole backlog. For flagged rows propose a step in the row so they
only confirm it; write it as `## Next action` / `- [ ] Next: ...` directly under the frontmatter.
If they cannot name one, that is the finding: the task is blocked on something not yet
identified. Waiting tasks count as defined (`- [ ] Waiting: ...`).

**Echo before writing, whenever answers were dictated as a list.** Show key, tier, urgent as one
table and wait for a yes. Dictated answers shifted by one row write tiers onto the wrong tasks.

## Pass 2: indicators, on the `4-high` items only

One table, one row per high item, one column per question:

| Key | Task | Due | Size: quick <30m / medium 30m-2h / long >2h / break down >=6h | Cold or run-up | Someone waiting on you? |
|---|---|---|---|---|---|

1. **Real deadline?** -> `due`, if genuine.
2. **Size** -> `timeEstimate` in minutes: quick `15`, medium `60`, long `180`, break down `360`.
3. **Cold or run-up?** -> `startable: cold | run-up`. Can it be dropped into a gap between
   meetings, or does it need a protected block? `schedule-work` depends on this.
4. **Is someone waiting on you?** -> tag `blocking-someone`. Ask it in exactly that direction; the
   mirror case (you are blocked on someone) is `waiting: true`. Never conflate them.

They answer tersely by key ("report: none, long, run-up, no") and can skip a slot; leave skipped
fields unset. Pre-fill only what is known (an existing `due`) and show it as filled.

**"Break down" is an instruction, not a size.** A twenty-hour task is not badly estimated, it is
under-decomposed. Write `360` as a floor and add the tag `needs-breakdown` ("cannot be estimated
until broken down"). Do not invent subtasks; `schedule-work` gives it a breakdown session.

## Pass 3: cap check

Count against the global cap and per live priority. Report both. If either is over, name what is
over and ask what drops.

## Quadrant: urgency is asked, importance is the tier

| | urgent | not urgent |
|---|---|---|
| **`4-high`** | `urgent-important` | `important-not-urgent` |
| **anything else** | `urgent-not-important` | `neither` |

Do not derive urgency from "has a due date soon": then a task with no date can never be urgent,
and "urgent but not written down yet" is exactly the state that matters. Asked, it costs one word.
Pre-fill a guess where a near date exists, have them correct exceptions, compute the quadrant and
show it back. **Urgent with no date is the important output:** those go on a "needs a date" list,
dated in Pass 2.

## Re-running

- **Default: unprioritised tasks only.** A full pass every time means it stops being run.
- **Pull from normal when high has room.** If high sits at 6 of 9, surface `3-normal` candidates
  for the open slots. The cap is the pull mechanism.
- **Full re-pass** on request. Staleness is judged from `prioritised:` (the ISO time priority was
  last set), written on every task touched.

## Improving this skill

When the user pushes back on how a run went, treat it as design input: turn it into concrete
options and let them choose. Record each adopted change here with its date and reason. **Never
edit the skill while a run is in progress**: a process amended mid-flight is a moving target the
user has to follow while doing the work. Collect improvements and apply them after.
