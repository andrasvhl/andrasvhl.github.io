# improve-product

A Claude Code skill that runs a design council on something you are building. Four roles (systems
designer, product manager, UI designer, copywriter), or six in Full mode (plus a QA engineer and a
behavioural psychologist), read how people actually used the product, agree one design, build it,
and then test it hands-on in a sandbox, round after round, until nothing serious is left.

Say "improve-product" or "run the council on the settings screen", and Claude asks Small or Full,
then runs the whole loop. It stops twice for you: to approve the proposal, and before deploying.

## How it works

1. **Goal stories from real use.** It reads your product's logs, chats or task records and
   writes 5 to 10 stories: what someone was trying to get done, what it cost them, and what done
   well looks like. Stories aim at the goal, not at replaying the old clicks.
2. **Design rounds.** Each role writes a position, then they vote on named conflicts. The QA
   engineer and psychologist count 0.75 of a vote by default. You get one proposal, with a
   separate list of everything that changes in today's behaviour, to veto line by line.
3. **Test rounds in a sandbox.** Each role uses the built product for real, one at a time on a
   fresh sandbox: clicks, sends, submits. Findings come back in three numbered tiers. Fix, test
   again, up to 3 rounds by default.

## Requirements

- Claude Code with sub-agents (any recent version).
- A product you can run locally or on a server you control.
- Optional: Claude in Chrome or another browser tool, for the hands-on rounds.

## Install

```bash
# from the unzipped improve-product folder
mkdir -p ~/.claude/skills
cp -r skill/improve-product ~/.claude/skills/
```

Start a new Claude Code session to load it. To scope it to one project instead, copy the folder
into `<project>/.claude/skills/`.

## First run

The first run sets itself up for your product: it asks where usage data lives (or proposes the
smallest log to add), then walks you through a sandbox: a separate copy of the app, seeded data, a
test login, and every outbound send (mail, payments, webhooks) stubbed. It proves the sandbox
works, then records the recipe in `settings.md`, so later runs start straight away.

## Settings

`skill/improve-product/settings.md`: default mode, vote weights, test round cap, usage window,
usage sources and sandbox recipes. Change any value.

## Cost

A Full run is a lot of tokens: six agents, two design rounds and up to three test rounds. Use
Small for a contained screen.

## License

MIT, see `LICENSE`.
