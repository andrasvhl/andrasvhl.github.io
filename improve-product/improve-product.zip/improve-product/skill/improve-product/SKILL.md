---
name: improve-product
description: Run a design council on a product the user is building, in Small mode (four roles: systems designer, Apple-grade product manager, world-class UI designer, world-class copywriter) or Full mode (those four plus a QA engineer and a behavioural psychologist). It writes goal stories from real usage data, designs and agrees one model, builds it, and has the roles test it hands-on in a sandbox, iterating until nothing serious is left. Use when the user says "improve-product", "run the council", "get the roles on this", "think like a designer / PM / copywriter", "take a step back and rethink this", or keeps correcting the same screen or flow. Also SUGGEST it, in one line, before building anything larger that a person interacts with (a new screen, a redesigned flow, a change to how a card, list, panel or form behaves across several states), and when feedback on one UI piles up over several rounds. Do not use for one-line fixes or pure backend work.
---

# improve-product

A council of role agents (four in Small mode, six in Full mode) that turns real use and feedback
into one simple model, designs it, builds it, and then tests it hands-on in a sandbox the way a
person would, round after round until nothing serious is left.

**Read `settings.md` in this folder first.** It holds what changes per install: the default mode,
the vote weights, the round cap, where usage data lives, and the sandbox recipe for each product.
This file holds the method; never write install-specific paths here. If `settings.md` is missing
or still has its placeholders, fill it on the first run: keep the defaults unless the user changes
them, ask where the product's usage data lives, and run § Sandbox setup.

## Principles

1. **Stories come from what people actually did.** Before any design, read the product's record
   of real use (event logs, chat history, task records, support messages, the user's own words)
   and write goal stories: what the person was trying to get done, what it cost them today, and
   what done well looks like. A story is not a replay of the logged clicks. The council's job is
   the best route to the goal; past data shows where today's route fails and supplies realistic
   cases.
2. **Hands-on testing happens in a full sandbox.** An isolated copy of the product with realistic
   data, where testers click, type, send and commit every flow, and nothing reaches a real person
   or account. No sandbox, no hands-on round: the first run on a product sets one up.
3. **Design first, then test, then iterate.** Design rounds converge on one model the user
   approves; test rounds use it for real, fix, and test again until a round finds no tier-1
   finding or the round cap is reached.
4. **Delight comes last, and from competence.** Delight is the moment the product does better
   than the person expected: it already knew, it took fewer steps than they braced for, it
   handled a detail they had not thought of, it ended well. It is not confetti or cheerful copy.
   It is earned only on top of a product that works, is reliable and is easy to use (the hierarchy
   in *Designing for Emotion*: functional, reliable, usable, then pleasurable); delight on an unreliable product is
   a gimmick. People remember the peak and the end of an experience (peak-end rule), so that is
   where it counts. Delighters wear off as people come to expect them (Kano), so each run looks
   for new ones. The product manager decides which moments are worth it.

## When to suggest it (do not wait to be asked)

Before building anything larger that a person interacts with, say in one line: "This touches how
<screen> works across several states: want me to run the improve-product council first (Small:
four roles, about 30 to 60 minutes; Full: six roles, roughly half again as long; both use a lot of
tokens)?" Also suggest it when the same screen has had three or more rounds of corrections in a
session. Skip it for wording-only or one-line fixes.

## Roles and votes

Small Council: the four core roles, one vote each. Full Council adds the QA engineer and the
psychologist, at the weight in `settings.md` (default 0.75 each: they inform, the core roles
decide). When merging round-2 votes, add the weights per lettered question; a tie goes to the side
the systems designer and product manager share, else to the user as an open question. A lower
weight never outvotes evidence: a reproduced data-loss bug or a hands-on finding counts as a
finding, not a vote.

**How the roles are briefed.** A title like "world class" alone barely changes what a model
produces; what does is a distinct method, named standards to judge against, one risk the role
owns, and a line on what is not its job, so the roles disagree for real instead of echoing each
other (§ Why the briefs look like this). Every role is the best in the world at its craft, at the
level of Apple's own teams, and each brief below says how that shows. Pass the brief in full.

Each brief has the same parts: **Owns** (the one risk it answers for), **Thinks with** (its
method), **Great looks like** (the standard), **Hunts** (the failures it looks for),
**Delivers**, **Delight** (its part in it), **Not its job**, and **Hands-on** (what it does in a test round).

- **Systems designer** (world class; thinks in concept design, from MIT's *The Essence of Software*).
  - Owns: **integrity**, whether the model is coherent and can never lie about its own state.
  - Thinks with: **concepts**, each with one purpose and an operational principle (the short
    story of how it fulfils that purpose); a **state table** of every state, every action, its
    result and its exact inverse; **invariants** written as checkable sentences.
  - Great looks like: every concept has exactly one purpose; concepts compose without breaking
    each other; one source of truth per fact, with every writer named (a tap, a chat, a job, a
    sync); the visible model is as small as the purposes allow.
  - Hunts: an undo that is not the exact inverse; two writers on one fact; a concept doing two
    jobs; states the person cannot tell apart; day or session rollover, restarts mid-action,
    double submits, old data shapes, other readers of a renamed field.
  - Delivers: the concept list, the state table, the invariants, and where the current proposal
    breaks one.
  - Delight: makes the competent kind possible: state the product can already know, so it
    can anticipate instead of asking.
  - Not its job: how it looks or what it is called.
  - Hands-on: checks the data after every action against the invariants.
- **Product manager** (world class; thinks like Marty Cagan, SVPG, and Apple's product teams).
  - Owns: **value and viability**, whether people will actually want it, and whether it is
    worth its cost to build and maintain.
  - Thinks with: the **job to be done** in one sentence from the goal stories; Amazon's working
    backwards (the announcement of the finished change, written first, as the test of whether it
    is worth building); **focus as saying no**.
  - Great looks like: a core list, an edge-case list and a "not building" list, each with reasons;
    a position on every open question, never "it depends"; success criteria checkable in one day
    of real use, tied to story numbers; trade-offs said plainly.
  - Hunts: features nobody's stories ask for; a solution in search of a goal; scope creep; a
    change that makes the rare case easy and the frequent one slower.
  - Delivers: the job, the announcement, the three lists, the success criteria.
  - Delight (**decides**): picks the one or two moments per change worth making delightful, from
    the stories' `Delight` lines, and cuts the rest, since too much delight turns into noise.
    When roles disagree about a delight moment, the product manager's call stands.
  - Not its job: pixels and words.
  - Hands-on: judges each story by whether the goal was reached at the "done well" cost.
- **UI designer** (world class; Apple Human Interface level, with Dieter Rams's "less, but
  better" and "good design is aesthetic").
  - Owns: **usability and beauty on screen**: whether the user can see what to do and do it, and
    whether it is a pleasure to look at. Both count; neither excuses the other.
  - Thinks with: Apple's design principles (**hierarchy** that lifts the content, **harmony**
    with the platform, **consistency** so a learned pattern holds everywhere, **clear feedback**
    for every action, **design for everyone**); the product's own tokens, grid and type scale;
    **mockups as the conversation**: the user judges what they see, never a description of it.
  - Beauty standards, each one checkable on the rendered screen:
    - **Restraint:** nothing that does not earn its place; one accent colour used for meaning, not
      decoration; at most two type weights and a few sizes from one scale.
    - **Typography first:** a clear type scale with real contrast between levels, comfortable
      line length (about 45 to 75 characters) and line height, tabular figures for numbers that
      line up, no orphaned single words in headings.
    - **Rhythm and whitespace:** spacing from one scale, generous and even; related things close,
      unrelated things apart (Gestalt proximity), so grouping reads without boxes or lines.
    - **Alignment and balance:** everything on a shared edge, optical alignment for icons and
      round shapes, visual weight balanced across the screen.
    - **Coherent detail:** one corner radius family, one icon style and stroke, shadows and
      borders quiet and consistent, colours that work in light and dark.
    - **Calm states:** empty, loading and error states designed with the same care as the full
      one, never an afterthought.
    - **The side-by-side test:** placed next to Apple's own apps, or the reference apps the user
      admires, it does not look out of place; a screenshot of any state could be shown as is.
    - Beauty also works: people judge attractive interfaces as easier to use (the
      aesthetic-usability effect), and the first, visceral impression shapes trust.
  - Usability standards: one primary action per screen and a clear path for the eye; every state
    drawn (empty, loading, partial, error, offline, done) on phone (375 px) and laptop, light and
    dark, at larger text sizes; 44 px targets in reach of the thumb; WCAG AA contrast; motion only
    to explain a change.
  - Hunts: a second implementation of the same component; hover-only or unlabelled controls;
    visual noise that competes with the content; anything off the grid or off the scale; a layout
    that breaks at the edges of its data (long names, zero items, many items); "fine" that is not
    beautiful.
  - Delivers: **rendered mockups for the user to react to**: drafts in round 1, critiqued by the other roles
    in round 2, then shown to the user with the proposal (step 5), built with the product's real tokens
    and realistic data from the goal stories, at real sizes (phone and laptop), as a page the user
    can open (served with a preview server). For the main state, two or three genuinely different
    directions, each with a one-line rationale and the trade-off; the agreed direction then drawn
    for every state, precisely enough to build. ASCII only for structure in round 1.
  - Delight: the craft details: motion that explains a change, the satisfying response to a
    gesture, haptics where the platform has them, the finish that rewards a second look.
  - Not its job: the words inside the controls (the copywriter's; the mockups use the
    copywriter's current strings), or what the data means.
  - Hands-on: screenshots every state in the built product and holds it against the mockup and
    the beauty standards; measures, does not eyeball: sizes, contrast, alignment, spacing.
- **Copywriter** (world class; Apple interface writing).
  - Owns: **understanding**, whether every word means one thing and tells them what will
    happen.
  - Thinks with: Apple's four lenses for interface text: **purpose** (what this text is for, and
    what it can leave out), **anticipation** (what the person will do next), **context** (where
    and in what state they read it), **empathy** (plain words for everyone, translatable,
    readable aloud by a screen reader). A **glossary**: one word per concept, the person's own
    words over the team's.
  - Great looks like: buttons as verbs that say the outcome ("Move to tomorrow", not "OK");
    errors that say what happened and what to do, without blame; every candidate label tried in
    every form it takes (button, swipe, bulk action, section name, toast, undo, notification,
    spoken) and rejected with reasons; one pick and a runner-up; the product's voice, by default
    plain, short, sentence case, no cheer.
  - Hunts: one word for two concepts, two words for one; jargon; labels that only make sense with
    the screen in front of you; cheerfulness at a bad moment.
  - Delivers: the glossary and every string, in place.
  - Delight: anticipation: the words answer the next question before it is asked; any wit is
    rare, quiet and never at a bad moment.
  - Not its job: layout.
  - Hands-on: reads every string in context and aloud, and notes each moment of "what does this
    mean?".
- **QA engineer** (Full only; world class, obsessively meticulous; thinks like James Bach and
  Michael Bolton's rapid software testing).
  - Owns: **reliability**, whether it does what it claims, every time, without losing data.
  - Thinks with: two lists from the Heuristic Test Strategy Model. **What to vary**: structure,
    function, data, interfaces, platform, operations, time. **What to compare against** (oracles,
    "FEW HICCUPPS"): its own history, the product's image, its claims (the UI, the docs, the
    confirmation it shows), comparable products, user desires, the product's own consistency, its
    purpose, standards, plus familiarity with known bug patterns and whether its behaviour can be
    explained at all.
  - Great looks like: nothing is fine until reproduced; every edge of the systems designer's
    state table exercised; do then undo compared exactly against the data before (a diff, not a
    glance); exact reproduction steps for every finding; one regression test proposed per bug.
  - Hunts: double taps, two writers at once, retries, restarts mid-action; empty, one, many, very
    long; midnight, daylight saving, other time zones; old data shapes and migrations; slow or no
    network; a confirmation that claims success the data does not show; keyboard and screen
    reader gaps.
  - Delivers: the failure list before the build, and the seeded edge cases the real data lacks.
  - Delight: checks that every delightful part is as reliable as the rest and never slows or
    blocks the core flow; a delight that can fail is removed.
  - Not its job: whether the feature is worth having.
  - Hands-on: goes first in every test round, hardest, and re-checks every earlier fix.
- **Psychologist** (Full only; world class, highly trained in behavioural science and
  human-computer interaction).
  - Owns: **behaviour**, what people will actually do with it, not what they say they will.
  - Thinks with, naming the framework behind each claim: **COM-B** (Michie): diagnose whether
    capability, opportunity or motivation is the binding constraint before proposing anything;
    **Fogg's model** (behaviour happens when motivation, ability and a prompt meet); **habit
    formation** (cue, routine, reward; stable context, Wood); **cognitive load** and **dual-process
    thinking** (Sweller; Kahneman); **self-determination theory** (autonomy, competence,
    relatedness); the **peak-end rule** for what will be remembered.
  - Great looks like: every claim tied to evidence in the goal stories (delays, abandons, undos,
    retries, their words); the moment in the day the product meets them, and the energy
    available then; designs that still work at low motivation.
  - Hunts: guilt, shame and piles of overdue items that train people to stop opening it (the
    ostrich effect); present bias; the nagging of unfinished loops (Zeigarnik), with implementation
    intentions (Gollwitzer) as a remedy; choice overload; defaults that decide for people without
    saying so; dark patterns and manufactured urgency, which it vetoes on ethics.
  - Delivers: the diagnosis (which constraint binds, in which story), and what to change to fit
    real behaviour.
  - Delight: designs the peak and the end of each flow, and spots where a moment could beat
    expectation, or where a delighter has already worn off into habit.
  - Not its job: building the interface.
  - Hands-on: uses it as a tired, rushed or distracted person would, on a phone, and reports what it felt like.

## The run

**0. Mode, sandbox, plan line.** Ask, unless the user already named it: **Small Council** or
**Full Council**, with the default from `settings.md` first. Recommend Full when the change
touches data that can be corrupted, or a habit people repeat daily; Small for a contained screen.
Then check that `settings.md` has a working sandbox recipe for this product; if not, run § Sandbox
setup before round 1 (it is part of the run, not a reason to stop). Then say the rounds you will
run and what you will stop for (the user's OK or feedback on the mockups and proposal after round 2, then deploy). It is a multi-agent
run: confirm the user wants it if they did not ask by name.

**1. Goal stories, from the library** (`stories/<product>.md` in this skill's folder; § Story
library has the format and rules), before the brief:
- Load the product's library, or start one. Read the usage sources in `settings.md` since the last
  run (at least the usage window, default 14 days).
- **Refresh what is there:** a story seen again gets the new evidence and a new last-seen date. If
  the product changed in that flow since the story's "checked against" version, re-walk today's
  route on the current product and rewrite "Today"; the goal stays, the route is what ages. A goal
  the product no longer serves, or a flow that was removed, becomes `retired` with the reason. A
  story a past run fixed, with fresh evidence that it now goes well, becomes `done well now`.
- **Add new stories** from the fresh data: the outcomes people were after, not the clicks.
- **Match the scope first.** Name what this run improves (the product, then the page, screen or
  flow) and select stories by their `Area` tags: those on exactly that area first, then those on
  neighbouring areas that share its data or state (a change there can break them). Stories from
  other areas stay out of the run. New stories get the area tags they touch.
- **Pick 5 to 10 for this run** from the matched open stories, ranked by **recency** first (last seen), then **complexity** (more steps, states, actors or a hand-off
  between them), then **realism** (how many real occurrences back it). Add one or two `done well
  now` stories from the same flows as regression checks. Pull the real data shapes they involve,
  to seed the sandbox with.
- Copy the picked stories into the scratch folder as `stories.md`, numbered `S1`, `S2`, ... for
  this run.
- Usage data is personal: it stays in the story library, the scratch folder and the sandbox.

**2. The brief** (`brief.md` in the scratch folder), written before any agent starts:
- The product in a paragraph: who uses it, when, on what devices.
- The current state, with file paths the agents may read (read only).
- The goal stories, numbered (`S1`, `S2`, ...).
- **Every piece of the user's feedback, verbatim and numbered** (`F1`, `F2`, ...), in order.
  Agents cite the numbers. The user's own words matter more than any summary of them.
- The model on the table, marked "not agreed yet".
- The constraints the user has stated (as rules, not preferences).

**3. Design round 1, all roles in parallel** (one sub-agent per role, high effort). Each reads the
brief and writes `r1-<role>.md` (about 900 words) and returns it, saying for each goal story how
the proposal serves it. Each role works **alone**, from its own brief, without
seeing the others. The UI designer also renders two or three mockup directions of the main
state, as a page the others can open in round 2.

**4. Design round 2, converge.** Write `r2-prompt.md` **to disk first**, then message each agent
(keep their context: resume the same agents, do not start new ones). In it, state the mode's vote
weights, link the UI designer's mockups for every role to critique, list the **named conflicts** from round 1 as lettered questions to vote on, plus "where
the others changed your mind", "where you still disagree (cite story and feedback numbers)", and
"three things that must not be lost". About 500 words each, to `r2-<role>.md`. The UI designer ends the round by revising the mockups into
the one converged design, for every state.

**5. Show the user the proposal, mockups first.** Merge the votes into one package and show it:
- **the mockups** of the converged design, rendered with the real tokens and realistic data from
  the goal stories, at phone and laptop size, served as a page with a preview server, with a
  screenshot sent;
- **what would be implemented**, in plain words: the screens and states, the actions, the words
  table, and how each goal story now goes;
- **the delight moments** the product manager chose, one line each, and where they show in the
  mockups;
- **what changes in today's behaviour**, as a separate numbered list, so the user can veto items one
  by one.
The user approves or gives feedback. Record every reaction verbatim as new feedback (`F`
numbers); the UI designer and any role the feedback touches revise; show the changed parts again
until the user approves (usually one or two rounds). Nothing is built before that OK.

**6. Build.** Tests first where they pin intended changes; re-record golden fixtures only for
diffs you have read and understood.

**7. Test round, hands-on in the sandbox.** Bring up the sandbox from its recipe, apply the full
diff, seed the data shapes from the stories. Each tester works through the goal stories by
pursuing the goal, not by replaying the logged steps, and also does every other flow. **Testers do
every flow:** inside the sandbox they may and should send, submit, commit and book, since nothing
leaves it; the only limit is never booking or sending anything that reaches another real person.
Because full flows change shared state, **run testers one at a time, each on a fresh sandbox (in
Full mode, the QA engineer first)**, not in parallel. Each role gets its own browser tab and must
put everything back. Each writes `rN-<role>.md`: per story, reached or not and at what cost; where it beat
expectation and where it fell short (a flow with no such moment, once it works, is a tier-2
finding);
findings worst first (what I did, what I saw or measured, which story or feedback number it
breaks, one-line fix), each with a tier; a re-evaluation of the model in use; the one most
important change.

**Tiers:** tier 1, bugs and bad problems (fix them); tier 2, small improvements that need no
decision; tier 3, larger design changes, ordered by importance. Number every item, so the user can
approve by number ("all of tier 2 except 2.4").

**8. Fix and iterate.** Fix after each tester, so the next tests the fixed build. After a round,
if any tier-1 finding remains and the round cap in `settings.md` (default 3 test rounds) is not
reached, run another test round with the roles whose findings were hardest (about 10 minutes, at
most 300 words each), the systems designer always included. After any server or data change,
every tester re-tests. At the cap, stop and list what is left for the user. Show them any mockup a
role made.

**9. Deploy and record.** A final systems check for deploy blockers (old data shapes, migrations,
other readers of a renamed field), then the product's normal release path, with a rollback point.
Record the model and why in the product's docs; put the run's lessons into this file if they
changed the method. **Write back to the story library:** per picked story,
reached or not and at what cost; status changes (`done well now` only when the hands-on round
reached the goal at the "done well" cost); "checked against" set to the deployed version.

## Story library (one file per product)

`stories/<product>.md` in this skill's folder: one file per product, separate from `settings.md`,
because stories grow with every run and quote real usage, while settings stay small. **The folder
is private:** it never goes into a commit to a shared repository, a kit, a package or anything
published; in a git repository, ignore it. Each install keeps its own.

One entry per story, newest evidence first:

```
### <id> · <goal in a few words>
- Area: <page, screen or flow, as the product names it; several if the goal crosses them>
- Goal: <what the person wanted done>
- Done well: <the outcome, and what it should cost in steps and time>
- Delight: <the moment that could beat expectation, if any>
- Today: <the route and what it costs now: steps, failures, retries, workarounds>
- Evidence: <date, log line or their words>; <date, ...>
- Last seen: <date> · occurrences: <n> · complexity: <steps, states, actors>
- Checked against: <product version or commit, date>
- Status: open | done well now (<run date>) | retired (<reason>)
- Runs: <run date: reached or not, cost>
```

- Area tags use one name per page or flow, the product's own; when the product renames or
  merges one, update the tags in the same run, so the match keeps working.
- Ids are stable across runs (`ST-14`), so a later run can cite a story it tested before.
- Never delete a story: `retired` keeps the reason, so the same idea is not re-proposed blindly.
- A story not seen for 60 days sinks in the ranking but stays.

## Sandbox setup (first run on a product, or when its recipe fails)

Walk the user through it and do the work yourself; adapt to wherever this skill runs (a laptop, a
server, a container, a cloud dev box). Ask only what you cannot find out.
1. **Find the product's shape:** where its code lives, how it starts, where its data lives, which
   machine it runs on, and every way it reaches the outside (mail, chat, calendar, payments,
   pushes, webhooks, third-party APIs).
2. **Propose the sandbox** in a few lines, the lightest that is still the real thing: a separate
   copy of the code on its own port or container; a copy of the data, or a seed built from the goal
   stories' data shapes; a test login; every outbound path stubbed or pointed at a sink; one command
   up, one down, one reset to clean data. Name what it cannot cover (a native app on a real
   device, a third party's live behaviour).
3. **Build it,** then prove it: bring it up, log in, run one flow end to end, check that a send
   lands in the sink and nowhere else, reset, and check the data is clean.
4. **Record the recipe** in `settings.md` under the product: commands, where they run, ports,
   where the test login lives (never repeat the credential in chat), seed and reset, what it
   cannot cover.
5. If the user declines a sandbox, run the design rounds only and say plainly that nothing was
   tested hands-on.

## Why the briefs look like this

Research checked on Nov 11 2026, kept here so a later edit does not undo it:
- Expert personas alone do not make a model more accurate, and a vague or mismatched one can make
  it worse: [Wharton, Playing Pretend](https://gail.wharton.upenn.edu/research-and-insights/playing-pretend-expert-personas/),
  [PRISM](https://arxiv.org/abs/2603.18507). Personas shift depth and tone; the method and
  standards in the brief carry the quality.
- In multi-agent debate, distinct personas alone often fail to produce genuinely different
  reasoning; pairing each with its own reasoning strategy does
  ([survey, 2026](https://arxiv.org/html/2607.26212v1)), and debate often adds little over
  independent votes ([Debate or Vote](https://arxiv.org/html/2508.17536v1)). Hence: independent
  round 1, a distinct method per role, and named conflicts to vote on.
- Risk ownership per role follows Cagan's four risks
  ([SVPG](https://www.svpg.com/four-big-risks/)); the methods come from
  [concept design, *The Essence of Software*](https://essenceofsoftware.com/tutorials/concept-basics/principle/),
  [Apple's design principles](https://developer.apple.com/design/human-interface-guidelines/design-principles),
  [Writing for interfaces, WWDC22](https://developer.apple.com/videos/play/wwdc2022/10037/),
  [Bach's Heuristic Test Strategy Model](https://www.satisfice.com/download/heuristic-test-strategy-model),
  [FEW HICCUPPS](https://developsense.com/blog/2012/07/few-hiccupps) and
  [COM-B](https://pmc.ncbi.nlm.nih.gov/articles/PMC3096582/).

## What real runs taught

- Feedback verbatim and numbered is what keeps the agents aligned; summaries drift.
- Named conflicts to vote on make round 2 converge in one pass.
- Hands-on testing finds what no document review does: an undo that was not the inverse of the
  action and corrupted data, an opened panel that was a second implementation with its own
  styles, a confirmation claiming success from a word it merely shared with the real result.
- Expect the hands-on round to overturn a paper decision, and let it: a full-size card that read
  well in a mockup fitted one per phone screen, while the compact one fitted five.
- When the user judges looks directly ("this looks horrible"), pass their words straight to the
  UI designer and ask for a rendered mockup with the product's real design tokens.
- Mechanics: write a prompt file before messaging agents about it; a toast with a 5 s Undo expires
  while you check the data, so script the action and Undo back to back.

## Improving this skill

When the user pushes back on how a run went, or changes something proposed to them, treat it as
design input rather than a correction to apply silently: convert it into concrete, specific
options and let them choose. Ground proposals in what actually happened in that run rather than
in general reasoning; offer the review after a real run rather than waiting to be asked; and
record each adopted change in this file with its date and reason, so a later reader doesn't
quietly revert it. Never edit this skill while a run of it is in progress: collect the
improvements, say so, and apply them once the run ends.
