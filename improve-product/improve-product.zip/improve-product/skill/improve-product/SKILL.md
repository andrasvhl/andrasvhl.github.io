---
name: improve-product
description: Run a design council on a product the user is building, in Small mode (four roles: systems designer, Apple-grade product manager, world-class UI designer, world-class copywriter) or Full mode (those four plus a QA engineer and a behavioural psychologist). It writes goal stories from real usage data, designs and agrees one model, builds it, and has the roles test it hands-on in a sandbox, iterating until nothing serious is left. Use when the user says "improve-product", "run the council", "get the roles on this", "think like a designer / PM / copywriter", "take a step back and rethink this", or keeps correcting the same screen or flow. Also SUGGEST it, in one line, before building anything larger that a person interacts with (a new screen, a redesigned flow, a change to how a card, list, panel or form behaves across several states), and when feedback on one UI piles up over several rounds. Do not use for one-line fixes or pure backend work.
---

# improve-product

A council of role agents (four in Small mode, six in Full mode) that turns real use and feedback
into one simple model, designs it, builds it, and then tests it hands-on in a sandbox the way a
person would, round after round until nothing serious is left.

**Read `settings.md` in this folder first.** It holds what changes per install: the default mode,
the vote weights, the round cap, where usage data lives, and the sandbox recipe for each product.
This file holds the method; never write install-specific paths here. If `settings.md` is missing
or still has its placeholders, fill it on the first run: keep the defaults unless the user changes
them, ask where the product's usage data lives, and run § Sandbox setup.

## Principles

1. **Stories come from what people actually did.** Before any design, read the product's record
   of real use (event logs, chat history, task records, support messages, the user's own words)
   and write goal stories: what the person was trying to get done, what it cost them today, and
   what done well looks like. A story is not a replay of the logged clicks. The council's job is
   the best route to the goal; past data shows where today's route fails and supplies realistic
   cases.
2. **Hands-on testing happens in a full sandbox.** An isolated copy of the product with realistic
   data, where testers click, type, send and commit every flow, and nothing reaches a real person
   or account. No sandbox, no hands-on round: the first run on a product sets one up.
3. **Design first, then test, then iterate.** Design rounds converge on one model the user
   approves; test rounds use it for real, fix, and test again until a round finds no tier-1
   finding or the round cap is reached.

## When to suggest it (do not wait to be asked)

Before building anything larger that a person interacts with, say in one line: "This touches how
<screen> works across several states: want me to run the improve-product council first (Small:
four roles, about 30 to 60 minutes; Full: six roles, roughly half again as long; both use a lot of
tokens)?" Also suggest it when the same screen has had three or more rounds of corrections in a
session. Skip it for wording-only or one-line fixes.

## Roles and votes

Small Council: the four core roles, one vote each. Full Council adds the QA engineer and the
psychologist, at the weight in `settings.md` (default 0.75 each: they inform, the core roles
decide). When merging round-2 votes, add the weights per lettered question; a tie goes to the side
the systems designer and product manager share, else to the user as an open question. A lower
weight never outvotes evidence: a reproduced data-loss bug or a hands-on finding counts as a
finding, not a vote.

- **Systems designer:** enumerate every constellation (all states, every action, undo of each,
  day or session boundaries, what other actors such as a background job or an assistant can
  change), what is true in the data for each, and reduce to the smallest set of user-visible
  states and actions. Flag where the current proposal breaks.
- **Product manager (Apple level):** the job the thing does in the person's day, grounded in the
  goal stories; what is core, what is an edge case, what to cut; positions on the open questions;
  success criteria checkable in one day of use; what not to build; trade-offs stated.
- **UI designer (Apple HIG level):** exactly what each state looks like on phone (375 px) and
  laptop; grid, edges, sizes, tap targets (44 px), what is tappable, discovery of rare actions
  without unlabelled icons; precise enough to build, ASCII sketches welcome.
- **Copywriter (Apple interface words):** every string; one word per concept and never two
  concepts sharing a word; test each candidate label in every form it takes (button, swipe, bulk
  action, section name, toast, undo); reject with reasons; pick one and a runner-up. Follow the
  product's own voice; by default plain, short, no cheer.
- **QA engineer (Full only):** the failure list before anything is built: every path that can
  corrupt or lose data (do and undo, two writers at once, restarts mid-action, old data shapes),
  the edge cases the real data lacks and must be seeded, and the regression tests that would pin
  the intended behaviour. In test rounds the QA engineer goes first and hardest, and checks that
  every undo restores the data exactly.
- **Psychologist, human behaviour (Full only):** how people will actually use it, not how they say
  they will: the moment in their day it meets them, attention and energy then, the habit loop
  (cue, action, reward), friction that makes them skip it, what feels like pressure or guilt, and
  which states quietly train avoidance. Grounds each claim in the goal stories' evidence. In test
  rounds, uses it as a tired or rushed person would and reports what it felt like.

## The run

**0. Mode, sandbox, plan line.** Ask, unless the user already named it: **Small Council** or
**Full Council**, with the default from `settings.md` first. Recommend Full when the change
touches data that can be corrupted, or a habit people repeat daily; Small for a contained screen.
Then check that `settings.md` has a working sandbox recipe for this product; if not, run § Sandbox
setup before round 1 (it is part of the run, not a reason to stop). Then say the rounds you will
run and what you will stop for (the user's OK on the proposal, then deploy). It is a multi-agent
run: confirm the user wants it if they did not ask by name.

**1. Goal stories** (`stories.md` in a scratch folder), before the brief:
- Read the usage sources in `settings.md` for the flows this run touches, over a window long
  enough to show repeated use (default the last 14 days).
- Find the outcomes people were after, not the clicks: each story is "Goal: <what they wanted
  done>. Evidence: <log lines, timestamps, their words>. Today: <steps, failures, retries,
  workarounds, time>. Done well: <the outcome and what it should cost>."
- 5 to 10 stories, the frequent goals first, plus the one or two rare ones where today's route
  failed worst. Pull the real data shapes they involve, to seed the sandbox with.
- Usage data is personal: it stays in the scratch folder and the sandbox, never in a commit or a
  shared file.

**2. The brief** (`brief.md` in the scratch folder), written before any agent starts:
- The product in a paragraph: who uses it, when, on what devices.
- The current state, with file paths the agents may read (read only).
- The goal stories, numbered (`S1`, `S2`, ...).
- **Every piece of the user's feedback, verbatim and numbered** (`F1`, `F2`, ...), in order.
  Agents cite the numbers. The user's own words matter more than any summary of them.
- The model on the table, marked "not agreed yet".
- The constraints the user has stated (as rules, not preferences).

**3. Design round 1, all roles in parallel** (one sub-agent per role, high effort). Each reads the
brief and writes `r1-<role>.md` (about 900 words) and returns it, saying for each goal story how
the proposal serves it.

**4. Design round 2, converge.** Write `r2-prompt.md` **to disk first**, then message each agent
(keep their context: resume the same agents, do not start new ones). In it, state the mode's vote
weights, list the **named conflicts** from round 1 as lettered questions to vote on, plus "where
the others changed your mind", "where you still disagree (cite story and feedback numbers)", and
"three things that must not be lost". About 500 words each, to `r2-<role>.md`.

**5. One proposal for the user.** Merge the votes into one model: words table, the screen, the
actions, how each goal story now goes, and **a separate list of what changes in today's
behaviour**, so the user can veto those one by one. Stop for their OK.

**6. Build.** Tests first where they pin intended changes; re-record golden fixtures only for
diffs you have read and understood.

**7. Test round, hands-on in the sandbox.** Bring up the sandbox from its recipe, apply the full
diff, seed the data shapes from the stories. Each tester works through the goal stories by
pursuing the goal, not by replaying the logged steps, and also does every other flow. **Testers do
every flow:** inside the sandbox they may and should send, submit, commit and book, since nothing
leaves it; the only limit is never booking or sending anything that reaches another real person.
Because full flows change shared state, **run testers one at a time, each on a fresh sandbox (in
Full mode, the QA engineer first)**, not in parallel. Each role gets its own browser tab and must
put everything back. Each writes `rN-<role>.md`: per story, reached or not and at what cost;
findings worst first (what I did, what I saw or measured, which story or feedback number it
breaks, one-line fix), each with a tier; a re-evaluation of the model in use; the one most
important change.

**Tiers:** tier 1, bugs and bad problems (fix them); tier 2, small improvements that need no
decision; tier 3, larger design changes, ordered by importance. Number every item, so the user can
approve by number ("all of tier 2 except 2.4").

**8. Fix and iterate.** Fix after each tester, so the next tests the fixed build. After a round,
if any tier-1 finding remains and the round cap in `settings.md` (default 3 test rounds) is not
reached, run another test round with the roles whose findings were hardest (about 10 minutes, at
most 300 words each), the systems designer always included. After any server or data change,
every tester re-tests. At the cap, stop and list what is left for the user. Show them any mockup a
role made.

**9. Deploy and record.** A final systems check for deploy blockers (old data shapes, migrations,
other readers of a renamed field), then the product's normal release path, with a rollback point.
Record the model and why in the product's docs; put the run's lessons into this file if they
changed the method.

## Sandbox setup (first run on a product, or when its recipe fails)

Walk the user through it and do the work yourself; adapt to wherever this skill runs (a laptop, a
server, a container, a cloud dev box). Ask only what you cannot find out.
1. **Find the product's shape:** where its code lives, how it starts, where its data lives, which
   machine it runs on, and every way it reaches the outside (mail, chat, calendar, payments,
   pushes, webhooks, third-party APIs).
2. **Propose the sandbox** in a few lines, the lightest that is still the real thing: a separate
   copy of the code on its own port or container; a copy of the data, or a seed built from the goal
   stories' data shapes; a test login; every outbound path stubbed or pointed at a sink; one command
   up, one down, one reset to clean data. Name what it cannot cover (a native app on a real
   device, a third party's live behaviour).
3. **Build it,** then prove it: bring it up, log in, run one flow end to end, check that a send
   lands in the sink and nowhere else, reset, and check the data is clean.
4. **Record the recipe** in `settings.md` under the product: commands, where they run, ports,
   where the test login lives (never repeat the credential in chat), seed and reset, what it
   cannot cover.
5. If the user declines a sandbox, run the design rounds only and say plainly that nothing was
   tested hands-on.

## What real runs taught

- Feedback verbatim and numbered is what keeps the agents aligned; summaries drift.
- Named conflicts to vote on make round 2 converge in one pass.
- Hands-on testing finds what no document review does: an undo that was not the inverse of the
  action and corrupted data, an opened panel that was a second implementation with its own
  styles, a confirmation claiming success from a word it merely shared with the real result.
- Expect the hands-on round to overturn a paper decision, and let it: a full-size card that read
  well in a mockup fitted one per phone screen, while the compact one fitted five.
- When the user judges looks directly ("this looks horrible"), pass their words straight to the
  UI designer and ask for a rendered mockup with the product's real design tokens.
- Mechanics: write a prompt file before messaging agents about it; a toast with a 5 s Undo expires
  while you check the data, so script the action and Undo back to back.

## Improving this skill

When the user pushes back on how a run went, or changes something proposed to them, treat it as
design input rather than a correction to apply silently: convert it into concrete, specific
options and let them choose. Ground proposals in what actually happened in that run rather than
in general reasoning; offer the review after a real run rather than waiting to be asked; and
record each adopted change in this file with its date and reason, so a later reader doesn't
quietly revert it. Never edit this skill while a run of it is in progress: collect the
improvements, say so, and apply them once the run ends.
