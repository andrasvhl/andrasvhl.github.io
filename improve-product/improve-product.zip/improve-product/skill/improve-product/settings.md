# improve-product settings (this install)

Read by the skill before every run. Change any value; the skill reads it fresh each time. The
first run fills in the usage sources and the sandbox for your product.

## Defaults

| Setting | Value |
|---|---|
| Default mode | Full Council |
| Core role vote (systems, product, UI, copy) | 1 |
| QA engineer and psychologist vote (Full only) | 0.75 |
| Test rounds cap | 3 |
| Usage window for goal stories | last 14 days |
| Effort for role agents | high |

## Usage sources (for goal stories)

<Filled on the first run. Where real use is recorded, for example: an event or tap log, request
logs, chat history, task or ticket records, support messages. If the product records nothing yet,
the first run proposes the smallest log worth adding, and works from the user's own words until
then.>

## Sandboxes

<One section per product, written by the first run (SKILL.md § Sandbox setup):>

### <product name>

- Up / down / reset: <commands, and the machine they run on>
- URL and port: <...>
- Test login: <where it lives; never the credential itself>
- Data: <copy of real data, or seed built from the goal stories>
- Outbound sends: <how each is stubbed or sunk>
- Cannot cover: <for example a native app on a real device>
